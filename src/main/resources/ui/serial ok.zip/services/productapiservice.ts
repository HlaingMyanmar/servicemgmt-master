
import { api } from './api';
import { ProductDTO, ApiResponse } from '../types';

export const productService = {
  getAll: async (): Promise<ProductDTO[]> => {
    const res = await api.get<any, ApiResponse<ProductDTO[]>>('/v1/products');
    return res.data;
  },

  getById: (id: number) => api.get<any, ApiResponse<ProductDTO>>(`/v1/products/${id}`).then((res: any) => res.data),
  
  create: (product: Partial<ProductDTO>) => 
    api.post<any, ApiResponse<ProductDTO>>('/v1/products', product).then((res: any) => res.data),
  
  update: (id: number, product: Partial<ProductDTO>) => 
    api.put<any, ApiResponse<ProductDTO>>(`/v1/products/${id}`, product).then((res: any) => res.data),
  
  delete: (id: number) => api.delete<any, ApiResponse<void>>(`/v1/products/${id}`).then((res: any) => res.data)
};
