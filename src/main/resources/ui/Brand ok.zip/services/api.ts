
import axios from 'https://esm.sh/axios@1.7.9';
import { AuthResponse, User, DashboardStats, ApiResponse } from '../types';
import { getFromSession, saveToSession, removeFromSession } from '../utils/storageHelper';

export const BASE_URL = 'http://localhost:8080/api';
export const WS_URL = 'http://localhost:8080/ws-clinic';

/**
 * Access Token is stored ONLY in JS memory (variable) to prevent XSS.
 * It will be lost on page reload.
 */
let _accessToken: string | null = null;

export const setAccessToken = (token: string | null) => {
  _accessToken = token;
};

export const getAccessToken = () => _accessToken;

/**
 * Shared Axios Instance
 */
export const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

/**
 * Request Interceptor
 * Injects token from JS Memory
 */
api.interceptors.request.use(config => {
  if (_accessToken) {
    config.headers.Authorization = `Bearer ${_accessToken}`;
  }
  return config;
});

/**
 * Response Interceptor
 */
api.interceptors.response.use(
  response => response.data,
  async (error) => {
    const originalRequest = error.config;
    
    // If token expired (401) and we haven't retried yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        // Attempt silent refresh using the refreshToken from sessionStorage (tab-isolated)
        const refreshRes = await authService.refresh();
        if (refreshRes.success) {
          setAccessToken(refreshRes.data.accessToken);
          originalRequest.headers.Authorization = `Bearer ${refreshRes.data.accessToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        authService.logout();
        window.location.href = '#/login';
      }
    }
    
    return Promise.reject(error.response?.data || { success: false, message: error.message });
  }
);

export const authService = {
  login: async (usernameOremail: string, password: string): Promise<ApiResponse<AuthResponse>> => {
    const response = await api.post<any, ApiResponse<any>>('/v1/auth/login', { usernameOremail, password });
    if (response.success) {
      setAccessToken(response.data.accessToken);
      // We only store refreshToken and user info in sessionStorage for tab-level persistence
      saveToSession('sspd_refresh', response.data.refreshToken);
      saveToSession('sspd_user', JSON.stringify({
        username: response.data.username,
        roles: response.data.roles,
        permissions: response.data.permissions
      }));
    }
    return response;
  },

  refresh: async (): Promise<ApiResponse<AuthResponse>> => {
    const refreshToken = getFromSession('sspd_refresh');
    if (!refreshToken) throw new Error('No refresh token available');
    
    // Usually backend expects refresh token in a cookie or body
    return api.post('/v1/auth/refresh', { refreshToken });
  },

  logout: () => {
    setAccessToken(null);
    removeFromSession('sspd_refresh');
    removeFromSession('sspd_user');
    removeFromSession('sspd_token'); // Clean up old legacy keys
  }
};

export const dashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    const response = await api.get<any, ApiResponse<DashboardStats>>('/v1/dashboard/stats');
    return response.data;
  }
};
