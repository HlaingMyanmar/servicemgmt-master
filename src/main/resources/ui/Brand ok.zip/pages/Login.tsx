
import React, { useState } from 'react';
import { User } from '../types';
import { authService } from '../services/api';
import { Lock, User as UserIcon, Loader2, AlertCircle } from 'lucide-react';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

interface LoginProps {
  onLoginSuccess: (user: User, token: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [usernameOremail, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await authService.login(usernameOremail, password);
      
      if (response.success) {
        await Swal.fire({
          icon: 'success',
          title: 'Secure Access Granted',
          text: `Welcome back, ${response.data.username}`,
          timer: 1500,
          showConfirmButton: false,
          position: 'center',
          backdrop: `rgba(15, 23, 42, 0.4)`,
          customClass: {
            popup: 'rounded-2xl border-none shadow-2xl font-inter',
            title: 'font-bold text-slate-800',
          }
        });

        const authData = response.data;
        onLoginSuccess({
          username: authData.username,
          roles: authData.roles,
          permissions: authData.permissions
        }, authData.accessToken);
      }
      
    } catch (err: any) {
      const errorMessage = err.message || 'Authentication failed. Please check your credentials.';
      setError(errorMessage);
      
      Swal.fire({
        icon: 'error',
        title: 'Access Denied',
        text: errorMessage,
        confirmButtonColor: '#6366f1',
        customClass: {
          popup: 'rounded-2xl border-none shadow-2xl',
          confirmButton: 'rounded-xl px-8 font-bold'
        }
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 p-6">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-white/10 animate-in fade-in zoom-in duration-500">
          <div className="p-8 pb-0 text-center">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-indigo-500/20 mb-4 transform rotate-3">
              <span className="text-3xl font-bold text-white tracking-tighter">S</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-800 tracking-tight">SSPD Enterprise</h2>
            <p className="text-slate-500 mt-2 text-sm">Service & Resource Management System</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-5">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-600 p-4 rounded-xl flex items-start gap-3 animate-in slide-in-from-top-2 duration-300">
                <AlertCircle size={20} className="mt-0.5 shrink-0" />
                <p className="text-sm font-medium leading-tight">{error}</p>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Username or Email</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                  <UserIcon size={18} />
                </div>
                <input
                  type="text"
                  required
                  autoFocus
                  value={usernameOremail}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none text-slate-700"
                  placeholder="Enter your account"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                  <Lock size={18} />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none text-slate-700"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center py-3.5 px-4 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-500/30 active:scale-[0.98] transition-all disabled:opacity-70 disabled:pointer-events-none shadow-lg shadow-indigo-600/20 mt-2"
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin mr-2" size={18} />
                  <span>Authenticating...</span>
                </>
              ) : (
                'Sign In to Dashboard'
              )}
            </button>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
              <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest"><span className="bg-white px-4 text-slate-400">Secure Access</span></div>
            </div>

            <p className="text-center text-[10px] text-slate-400 leading-relaxed">
              Proprietary system of SSPD. Unauthorized access is strictly prohibited and monitored.
            </p>
          </form>
        </div>
        
        <p className="text-center text-slate-400/60 text-xs mt-8">
          &copy; 2026 SSPD IT Solution. Build v1.0.4-stable
        </p>
      </div>
    </div>
  );
};

export default Login;
