
import React, { useEffect, useState, useCallback } from 'react';
import { roleService } from '../services/roleapiservice';
import { permissionService } from '../services/permissionapiservice';
import { RoleDTO, PermissionDTO } from '../types';
import { 
  Loader2, Plus, ShieldCheck, Key, Settings2, Search, 
  Trash2, Edit2, Wifi, Save, X, CheckSquare, Square,
  CheckCircle2, MinusSquare
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const RoleManagement: React.FC = () => {
  const [roles, setRoles] = useState<RoleDTO[]>([]);
  const [allPermissions, setAllPermissions] = useState<PermissionDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<RoleDTO | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });
  const [selectedPermissionIds, setSelectedPermissionIds] = useState<number[]>([]);
  const [permSearchTerm, setPermSearchTerm] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [roleData, permData] = await Promise.all([
        roleService.getAll(),
        permissionService.getAll()
      ]);
      setRoles(roleData);
      setAllPermissions(permData);
    } catch (error) {
      console.error("Failed to load RBAC data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleWsMessage = useCallback((message: string) => {
    setWsStatus('online');
    fetchData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchData]);

  useWebsocket('/topic/role', handleWsMessage);

  const handleOpenRoleModal = (role?: RoleDTO) => {
    if (role) {
      setEditingRole(role);
      setFormData({ name: role.name, description: role.description || '' });
    } else {
      setEditingRole(null);
      setFormData({ name: 'ROLE_', description: '' });
    }
    setIsModalOpen(true);
  };

  const handleOpenAssignModal = (role: RoleDTO) => {
    setEditingRole(role);
    setSelectedPermissionIds(role.permissions.map(p => p.id));
    setPermSearchTerm('');
    setIsAssignModalOpen(true);
  };

  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingRole) {
        await roleService.update(editingRole.id, formData);
      } else {
        await roleService.create(formData);
      }
      setIsModalOpen(false);
      fetchData();
      Swal.fire({ icon: 'success', title: 'Updated', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Action failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleAssignPermissions = async () => {
    if (!editingRole) return;
    setSaving(true);
    try {
      await roleService.assignPermissions(editingRole.id, selectedPermissionIds);
      Swal.fire({ icon: 'success', title: 'Synced', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
      setIsAssignModalOpen(false);
      fetchData();
    } catch (error: any) {
      Swal.fire('Failed', error.message || 'Sync failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const togglePermission = (id: number) => {
    setSelectedPermissionIds(prev => 
      prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]
    );
  };

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-600" size={32} />
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-400">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">System Roles</h2>
          <p className="text-slate-500 text-xs">Manage security groups.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" placeholder="Search..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 outline-none text-xs w-48 transition-all"
            />
          </div>
          <button 
            onClick={() => handleOpenRoleModal()}
            className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-md hover:bg-indigo-700 transition-all flex items-center gap-1.5"
          >
            <Plus size={14} /> Create Role
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
        {roles.filter(r => r.name.toLowerCase().includes(searchTerm.toLowerCase())).map(role => (
          <div key={role.id} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition-all relative group overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 flex gap-1">
              <button onClick={() => handleOpenRoleModal(role)} className="p-1 text-slate-400 hover:text-indigo-600"><Edit2 size={14} /></button>
            </div>
            
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600"><ShieldCheck size={24} /></div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 tracking-tight">{role.name}</h3>
                <p className="text-[9px] text-slate-400 font-bold uppercase">ID: #{role.id}</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 line-clamp-2 min-h-[32px]">{role.description || "Security level."}</p>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-1.5">
                <span>Access Keys</span>
                <span className="bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded-full">{role.permissions.length}</span>
              </div>
              
              <button 
                onClick={() => handleOpenAssignModal(role)}
                className="w-full py-2 bg-slate-50 hover:bg-indigo-600 text-slate-500 hover:text-white rounded-lg text-[10px] font-bold transition-all border border-slate-100 flex items-center justify-center gap-1.5"
              >
                <Settings2 size={12} />
                Manage Permissions
              </button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800">{editingRole ? 'Update Role' : 'Create Role'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 rounded-full"><X size={16} className="text-slate-400" /></button>
            </div>
            <form onSubmit={handleSaveRole} className="p-4 space-y-3 text-left">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Role Name</label>
                <input
                  type="text" required value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value.toUpperCase().replace(/\s/g, '_')})}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Description</label>
                <textarea
                  rows={2} value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none resize-none"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-2 border border-slate-200 rounded-lg text-xs font-bold">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold shadow-md">Confirm</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAssignModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-xl rounded-xl shadow-2xl overflow-hidden border border-slate-200 max-h-[80vh] flex flex-col animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Permissions for {editingRole?.name}</h3>
                <p className="text-[10px] text-slate-400 font-medium">Update access keys</p>
              </div>
              <button onClick={() => setIsAssignModalOpen(false)} className="p-1 hover:bg-slate-100 rounded-full"><X size={16} className="text-slate-400" /></button>
            </div>

            <div className="px-4 py-3 border-b border-slate-100 bg-white flex flex-col sm:flex-row items-center gap-2">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                <input 
                  type="text" placeholder="Search permissions..." 
                  value={permSearchTerm}
                  onChange={(e) => setPermSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg outline-none text-[10px]"
                />
              </div>
              <div className="flex items-center gap-1.5 w-full sm:w-auto">
                <button onClick={() => setSelectedPermissionIds(allPermissions.filter(p => p.name.toLowerCase().includes(permSearchTerm.toLowerCase())).map(p => p.id))} className="flex-1 sm:flex-none px-2 py-1.5 text-[9px] font-bold uppercase bg-emerald-50 text-emerald-600 rounded-md">Select All</button>
                <button onClick={() => setSelectedPermissionIds(prev => prev.filter(id => !allPermissions.filter(p => p.name.toLowerCase().includes(permSearchTerm.toLowerCase())).map(p => p.id).includes(id)))} className="flex-1 sm:flex-none px-2 py-1.5 text-[9px] font-bold uppercase bg-rose-50 text-rose-600 rounded-md">Clear</button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {allPermissions.filter(p => p.name.toLowerCase().includes(permSearchTerm.toLowerCase())).map(perm => {
                  const isSelected = selectedPermissionIds.includes(perm.id);
                  return (
                    <button 
                      key={perm.id}
                      onClick={() => togglePermission(perm.id)}
                      className={`flex items-center gap-2.5 p-3 rounded-lg border transition-all text-left ${
                        isSelected ? 'bg-indigo-50 border-indigo-100 text-indigo-700' : 'bg-white border-slate-100 text-slate-600'
                      }`}
                    >
                      {isSelected ? <CheckSquare size={16} /> : <Square size={16} />}
                      <div>
                        <p className="text-xs font-bold leading-none">{perm.name}</p>
                        <p className={`text-[9px] mt-1 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`}>System key</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase">{selectedPermissionIds.length} Keys Selected</span>
              <div className="flex gap-2">
                <button onClick={() => setIsAssignModalOpen(false)} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold bg-white">Cancel</button>
                <button onClick={handleAssignPermissions} disabled={saving} className="px-4 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold shadow-md">Apply</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoleManagement;
