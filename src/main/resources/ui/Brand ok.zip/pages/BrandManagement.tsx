
import React, { useEffect, useState, useCallback } from 'react';
import { brandService } from '../services/brandapiservice';
import { BrandDTO } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, Wifi, Save, X, 
  Package, CheckCircle2, AlertCircle, RefreshCcw
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const BrandManagement: React.FC = () => {
  const [brands, setBrands] = useState<BrandDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState<BrandDTO | null>(null);
  const [formData, setFormData] = useState({ name: '', isActive: true });
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const data = await brandService.getAll();
      setBrands(data);
    } catch (error) {
      console.error("Failed to load brands", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleWsMessage = useCallback((message: string) => {
    setWsStatus('online');
    fetchData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchData]);

  useWebsocket('/topic/brand', handleWsMessage);

  const handleOpenModal = (brand?: BrandDTO) => {
    if (brand) {
      setEditingBrand(brand);
      setFormData({ name: brand.name, isActive: brand.isActive });
    } else {
      setEditingBrand(null);
      setFormData({ name: '', isActive: true });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingBrand) {
        await brandService.update(editingBrand.id, formData);
      } else {
        await brandService.create(formData);
      }
      setIsModalOpen(false);
      fetchData();
      Swal.fire({ icon: 'success', title: 'Saved', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'System error', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Remove?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes'
    });

    if (result.isConfirmed) {
      try {
        await brandService.delete(id);
        fetchData();
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-600" size={32} />
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-400">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
        <div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">Brand Directory</h2>
          <p className="text-slate-500 text-xs">Maintain corporate brands.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" placeholder="Filter..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg outline-none text-xs w-48 transition-all"
            />
          </div>
          <button 
            onClick={() => handleOpenModal()}
            className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-md flex items-center gap-1.5"
          >
            <Plus size={14} /> Add Brand
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50/50 border-b border-slate-100">
            <tr>
              <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Brand Label</th>
              <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest text-center">Status</th>
              <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {brands.filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase())).map((brand) => (
              <tr key={brand.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-4 py-2.5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                      <Package size={16} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-700 tracking-tight">{brand.name}</p>
                      <p className="text-[8px] text-slate-400 font-bold uppercase tracking-tight">ID: BR-{brand.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-2.5">
                  <div className="flex justify-center">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                      brand.isActive ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {brand.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-2.5">
                  <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleOpenModal(brand)} className="p-1.5 text-slate-400 hover:text-indigo-600"><Edit2 size={14} /></button>
                    <button onClick={() => handleDelete(brand.id)} className="p-1.5 text-slate-400 hover:text-rose-600"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between text-left">
              <h3 className="text-sm font-bold text-slate-800">{editingBrand ? 'Edit Brand' : 'New Brand'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 rounded-full"><X size={16} className="text-slate-400" /></button>
            </div>
            <form onSubmit={handleSave} className="p-4 space-y-3 text-left">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Brand Name</label>
                <input type="text" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none" />
              </div>
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, isActive: !formData.isActive})}
                  className={`w-9 h-5 rounded-full transition-all relative ${formData.isActive ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all ${formData.isActive ? 'left-4.5' : 'left-0.5'}`}></div>
                </button>
                <span className="text-[10px] font-bold text-slate-700 uppercase">Status: {formData.isActive ? 'Active' : 'Inactive'}</span>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-2 border border-slate-200 rounded-lg text-xs font-bold">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold shadow-md">Confirm</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrandManagement;
