
import React, { useEffect, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package, 
  Users, 
  Wrench, 
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { DashboardStats } from '../types';
import { dashboardService } from '../services/api';

const chartData = [
  { name: 'Mon', sales: 4000, services: 2400 },
  { name: 'Tue', sales: 3000, services: 1398 },
  { name: 'Wed', sales: 2000, services: 9800 },
  { name: 'Thu', sales: 2780, services: 3908 },
  { name: 'Fri', sales: 1890, services: 4800 },
  { name: 'Sat', sales: 2390, services: 3800 },
  { name: 'Sun', sales: 3490, services: 4300 },
];

const StatCard = ({ title, value, change, icon, color, trend }: any) => (
  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col justify-between hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start">
      <div className={`p-2 rounded-lg bg-${color}-50 text-${color}-600`}>
        {React.cloneElement(icon, { size: 18 })}
      </div>
      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${trend === 'up' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'} flex items-center gap-0.5`}>
        {trend === 'up' ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
        {change}
      </span>
    </div>
    <div className="mt-3">
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{title}</p>
      <h3 className="text-lg font-bold text-slate-800 mt-0.5">{value}</h3>
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await dashboardService.getStats();
        setStats(data);
      } catch (err) {
        console.error("Failed to fetch dashboard stats", err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="animate-spin text-indigo-600" size={32} />
          <p className="text-xs text-slate-500 font-medium animate-pulse">Loading Analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-400">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">Business Overview</h2>
          <p className="text-slate-500 text-xs">Real-time performance metrics.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer hover:bg-slate-50 transition-colors shadow-sm">
            <Clock size={14} className="text-slate-400" />
            Active Session
          </div>
          <button className="bg-indigo-600 text-white px-4 py-1.5 rounded-lg text-xs font-bold shadow-md shadow-indigo-600/10 hover:bg-indigo-700 transition-all active:scale-95">
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Revenue" 
          value={`Ks ${(stats?.totalSales || 0).toLocaleString()}`} 
          change="+12.5%" 
          trend="up" 
          icon={<DollarSign />} 
          color="indigo" 
        />
        <StatCard 
          title="Services Rendered" 
          value={stats?.totalServices || 0} 
          change="+3.2%" 
          trend="up" 
          icon={<Wrench />} 
          color="amber" 
        />
        <StatCard 
          title="Stock Inventory" 
          value="1,240 Units" 
          change="-4.5%" 
          trend="down" 
          icon={<Package />} 
          color="rose" 
        />
        <StatCard 
          title="Total Customers" 
          value={stats?.totalCustomers || 0} 
          change="+18.4%" 
          trend="up" 
          icon={<Users />} 
          color="sky" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-800 text-sm">Growth Trajectory</h3>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Revenue</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-indigo-200"></span>
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Services</span>
              </div>
            </div>
          </div>
          <div className="h-[240px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 500}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 500}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: '11px'}}
                />
                <Area type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorSales)" />
                <Area type="monotone" dataKey="services" stroke="#e0e7ff" strokeWidth={1.5} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 text-sm mb-4">Inventory Health</h3>
          <div className="space-y-4">
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-[10px] font-bold">
                <span className="text-slate-500">Available Units</span>
                <span className="text-slate-800">82%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[82%] rounded-full"></div>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-[10px] font-bold">
                <span className="text-slate-500">Returns</span>
                <span className="text-slate-800">4%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 w-[4%] rounded-full"></div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-slate-100">
            <h4 className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-3">Critical Stock</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center text-rose-500 border border-rose-100">
                  <AlertCircle size={16} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-700">Canon XL Ink</p>
                  <p className="text-[9px] text-rose-600 font-bold uppercase">Out of Stock</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-500 border border-amber-100">
                  <Clock size={16} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-700">Dell Laptop Fan</p>
                  <p className="text-[9px] text-amber-600 font-bold uppercase">2 units left</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-800 text-sm">Sales Ledger</h3>
            <p className="text-[10px] text-slate-500">Active terminal stream.</p>
          </div>
          <button className="text-indigo-600 font-bold text-xs flex items-center gap-1 hover:bg-indigo-50 px-2 py-1 rounded-md">
            Full History <ArrowRight size={12} />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Invoice</th>
                <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Client</th>
                <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Amount</th>
                <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(stats?.recentSales || []).map((sale) => (
                <tr key={sale.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-bold text-slate-700">{sale.saleCode}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{sale.customerName}</td>
                  <td className="px-4 py-3 text-xs font-bold text-slate-900">Ks {sale.amount.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                      sale.status === 'Paid' ? 'bg-emerald-50 text-emerald-600' :
                      sale.status === 'Partial' ? 'bg-amber-50 text-amber-600' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {sale.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button className="p-1 text-slate-300 hover:text-indigo-600 transition-all">
                      <ArrowRight size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
