import React, { useState, useEffect } from 'react';
import { journalApiService } from '../services/journalapiservice';
import { coaService } from '../services/coaapiservice';
import { staffService } from '../services/staffapiservice';
import { JournalEntryDTO, JournalDetailDTO, ChartOfAccountDTO, StaffDTO } from '../types';
import { Plus, Trash2, Save, AlertCircle, CheckCircle2 } from 'lucide-react';
import Swal from 'sweetalert2';

const JournalEntryManagement: React.FC = () => {
  const [accounts, setAccounts] = useState<ChartOfAccountDTO[]>([]);
  const [staffs, setStaffs] = useState<StaffDTO[]>([]);
  const [referenceNo, setReferenceNo] = useState('');
  const [description, setDescription] = useState('');
  const [selectedStaffId, setSelectedStaffId] = useState<number>(0);
  const [details, setDetails] = useState<JournalDetailDTO[]>([
    { accountId: 0, debit: 0, credit: 0 },
    { accountId: 0, debit: 0, credit: 0 }
  ]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [coaRes, staffRes] = await Promise.all([
          coaService.getAll(),
          staffService.getAll()
        ]);
        setAccounts(coaRes);
        setStaffs(staffRes);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const handleAddRow = () => {
    setDetails([...details, { accountId: 0, debit: 0, credit: 0 }]);
  };

  const handleRemoveRow = (index: number) => {
    if (details.length <= 2) return;
    const newDetails = [...details];
    newDetails.splice(index, 1);
    setDetails(newDetails);
  };

  const handleDetailChange = (index: number, field: keyof JournalDetailDTO, value: any) => {
    const newDetails = [...details];
    newDetails[index] = { ...newDetails[index], [field]: value };
    
    // If debit is entered, clear credit and vice versa (usually)
    if (field === 'debit' && value > 0) newDetails[index].credit = 0;
    if (field === 'credit' && value > 0) newDetails[index].debit = 0;
    
    setDetails(newDetails);
  };

  const totalDebit = details.reduce((sum, d) => sum + (Number(d.debit) || 0), 0);
  const totalCredit = details.reduce((sum, d) => sum + (Number(d.credit) || 0), 0);
  const isBalanced = totalDebit > 0 && totalDebit === totalCredit;
  const isValid = isBalanced && referenceNo && selectedStaffId > 0 && details.every(d => d.accountId > 0);

  const handleSave = async () => {
    if (!isValid) return;

    try {
      const payload: JournalEntryDTO = {
        referenceNo,
        description,
        staffId: selectedStaffId,
        details: details.map(d => ({
          accountId: Number(d.accountId),
          debit: Number(d.debit),
          credit: Number(d.credit)
        }))
      };

      const res = await journalApiService.create(payload);
      if (res) {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Journal Entry saved successfully',
          timer: 2000,
          showConfirmButton: false
        });
        // Reset form
        setReferenceNo('');
        setDescription('');
        setDetails([
          { accountId: 0, debit: 0, credit: 0 },
          { accountId: 0, debit: 0, credit: 0 }
        ]);
      }
    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'Failed to save journal entry'
      });
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">New Journal Entry</h2>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
        {/* Header Form */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Reference No</label>
            <input 
              type="text" 
              value={referenceNo}
              onChange={(e) => setReferenceNo(e.target.value)}
              placeholder="e.g. JE-001"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Staff / Prepared By</label>
            <select 
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
            >
              <option value={0}>Select Staff</option>
              {staffs.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Description</label>
            <input 
              type="text" 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter description..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
            />
          </div>
        </div>

        {/* Details Table */}
        <div className="border border-slate-100 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-wider">
                <th className="px-4 py-3 border-b border-slate-100">Account</th>
                <th className="px-4 py-3 border-b border-slate-100 text-right w-32">Debit</th>
                <th className="px-4 py-3 border-b border-slate-100 text-right w-32">Credit</th>
                <th className="px-4 py-3 border-b border-slate-100 w-12"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {details.map((detail, index) => (
                <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-2">
                    <select 
                      value={detail.accountId}
                      onChange={(e) => handleDetailChange(index, 'accountId', Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-transparent border-none text-sm focus:ring-0 focus:outline-none"
                    >
                      <option value={0}>Select Account</option>
                      {accounts.map(acc => (
                        <option key={acc.id} value={acc.id}>{acc.accountName} ({acc.code})</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2">
                    <input 
                      type="number" 
                      value={detail.debit || ''}
                      onChange={(e) => handleDetailChange(index, 'debit', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="w-full px-2 py-1.5 bg-transparent border-none text-sm text-right focus:ring-0 focus:outline-none font-medium text-emerald-600"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input 
                      type="number" 
                      value={detail.credit || ''}
                      onChange={(e) => handleDetailChange(index, 'credit', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="w-full px-2 py-1.5 bg-transparent border-none text-sm text-right focus:ring-0 focus:outline-none font-medium text-rose-600"
                    />
                  </td>
                  <td className="px-4 py-2 text-center">
                    <button 
                      onClick={() => handleRemoveRow(index)}
                      className="p-1.5 text-slate-300 hover:text-rose-500 transition-colors"
                      disabled={details.length <= 2}
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50/50 font-bold text-sm">
                <td className="px-4 py-3 text-slate-500">Total</td>
                <td className="px-4 py-3 text-right text-emerald-600">
                  {new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(totalDebit)}
                </td>
                <td className="px-4 py-3 text-right text-rose-600">
                  {new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(totalCredit)}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="flex items-center justify-between pt-4">
          <button 
            onClick={handleAddRow}
            className="flex items-center gap-2 px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-sm font-bold transition-all"
          >
            <Plus size={16} />
            Add Account Row
          </button>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              {isBalanced ? (
                <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
                  <CheckCircle2 size={14} />
                  Balanced
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-rose-500 text-xs font-bold">
                  <AlertCircle size={14} />
                  Out of Balance: {Math.abs(totalDebit - totalCredit).toFixed(2)}
                </div>
              )}
            </div>

            <button 
              disabled={!isValid}
              onClick={handleSave}
              className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all shadow-lg
                ${isValid 
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200' 
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'}`}
            >
              <Save size={16} />
              Save Journal Entry
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JournalEntryManagement;
