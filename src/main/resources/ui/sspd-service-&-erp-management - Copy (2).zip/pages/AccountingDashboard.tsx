import React, { useState, useEffect } from 'react';
import { accountingApiService } from '../services/accountingapiservice';
import { AccountBalanceDTO, PaymentTransactionDTO, AccountType } from '../types';
import { Wallet, Landmark, PieChart, RefreshCw, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

const AccountingDashboard: React.FC = () => {
  const [balances, setBalances] = useState<AccountBalanceDTO[]>([]);
  const [transactions, setTransactions] = useState<PaymentTransactionDTO[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [balanceRes, transRes] = await Promise.all([
        accountingApiService.getAllBalances(),
        accountingApiService.getAllTransactions()
      ]);
      setBalances(balanceRes);
      setTransactions(transRes);
    } catch (error) {
      console.error('Error fetching accounting data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Calculate totals (Mocking the logic since we don't have account types in AccountBalanceDTO directly, 
  // but we can infer or assume we might need to fetch COA to match types if needed. 
  // For now, let's assume we might need to fetch COA or just display what we have.)
  // Actually, the request says "Account Balances Table: အကောင့်တစ်ခုချင်းစီရဲ့ လက်ရှိကျန်ငွေ (Trial Balance) ကို ပြပေးရမယ်"
  // And Stats Cards for Assets, Liabilities, Equity.
  
  // To get types, I should probably fetch COA as well.
  
  const totalAssets = 0; // Placeholder
  const totalLiabilities = 0; // Placeholder
  const totalEquity = 0; // Placeholder

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">Accounting Overview</h2>
        <button 
          onClick={fetchData}
          className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50 transition-all"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          Refresh Data
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <Wallet size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Assets</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalAssets)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
              <Landmark size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Liabilities</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalLiabilities)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
              <PieChart size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Equity</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalEquity)}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Account Balances Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h3 className="font-bold text-slate-800 text-sm">Account Balances (Trial Balance)</h3>
          </div>
          <div className="overflow-auto max-h-[400px] custom-scrollbar">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-white z-10 shadow-sm">
                <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-wider">
                  <th className="px-4 py-3 border-b border-slate-100">Account Name</th>
                  <th className="px-4 py-3 border-b border-slate-100">Fiscal Year</th>
                  <th className="px-4 py-3 border-b border-slate-100 text-right">Current Balance</th>
                  <th className="px-4 py-3 border-b border-slate-100 text-right">Last Updated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {balances.length > 0 ? (
                  balances.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50 transition-colors text-xs">
                      <td className="px-4 py-3 font-medium text-slate-700">{b.accountName}</td>
                      <td className="px-4 py-3 text-slate-500">{b.fiscalYear}</td>
                      <td className={`px-4 py-3 text-right font-bold ${b.currentBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(b.currentBalance)}
                      </td>
                      <td className="px-4 py-3 text-right text-slate-400">
                        {new Date(b.lastUpdated).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-slate-400 italic">No balance records found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Payment Transactions Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h3 className="font-bold text-slate-800 text-sm">Recent Payment Transactions</h3>
          </div>
          <div className="overflow-auto max-h-[400px] custom-scrollbar">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-white z-10 shadow-sm">
                <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-wider">
                  <th className="px-4 py-3 border-b border-slate-100">Ref No</th>
                  <th className="px-4 py-3 border-b border-slate-100">Type</th>
                  <th className="px-4 py-3 border-b border-slate-100">Method</th>
                  <th className="px-4 py-3 border-b border-slate-100 text-right">Amount</th>
                  <th className="px-4 py-3 border-b border-slate-100">Trans No</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions.length > 0 ? (
                  transactions.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition-colors text-xs">
                      <td className="px-4 py-3 font-medium text-slate-700">#{t.referenceId}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-bold uppercase">
                          {t.referenceType}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500">{t.paymentMethodName}</td>
                      <td className="px-4 py-3 text-right font-bold text-indigo-600">
                        {new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(t.amount)}
                      </td>
                      <td className="px-4 py-3 text-slate-400 font-mono">{t.transactionNo}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-400 italic">No transactions found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountingDashboard;
