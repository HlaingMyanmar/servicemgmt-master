import React, { useState, useEffect } from 'react';
import { purchaseApiService } from '../services/purchaseapiservice';
import { supplierService } from '../services/supplierapiservice';
import { staffService } from '../services/staffapiservice';
import { productService } from '../services/productapiservice';
import { PurchaseDTO, PurchaseDetailDTO, SupplierDTO, StaffDTO, ProductDTO } from '../types';
import { Plus, Trash2, Save, ShoppingCart, Hash, DollarSign, User } from 'lucide-react';
import Swal from 'sweetalert2';

const PurchaseManagement: React.FC = () => {
  const [suppliers, setSuppliers] = useState<SupplierDTO[]>([]);
  const [staffs, setStaffs] = useState<StaffDTO[]>([]);
  const [products, setProducts] = useState<ProductDTO[]>([]);
  
  const [selectedSupplierId, setSelectedSupplierId] = useState<number>(0);
  const [selectedStaffId, setSelectedStaffId] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [remark, setRemark] = useState('');
  
  const [details, setDetails] = useState<PurchaseDetailDTO[]>([
    { productId: 0, qty: 1, unitCost: 0, subtotal: 0, serialNumbers: [''] }
  ]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [supRes, staffRes, prodRes] = await Promise.all([
          supplierService.getAll(),
          staffService.getAll(),
          productService.getAll()
        ]);
        setSuppliers(supRes);
        setStaffs(staffRes);
        setProducts(prodRes);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const handleAddRow = () => {
    setDetails([...details, { productId: 0, qty: 1, unitCost: 0, subtotal: 0, serialNumbers: [''] }]);
  };

  const handleRemoveRow = (index: number) => {
    if (details.length <= 1) return;
    const newDetails = [...details];
    newDetails.splice(index, 1);
    setDetails(newDetails);
  };

  const handleDetailChange = (index: number, field: keyof PurchaseDetailDTO, value: any) => {
    const newDetails = [...details];
    const detail = { ...newDetails[index], [field]: value };

    if (field === 'qty') {
      const qty = parseInt(value) || 0;
      detail.qty = qty;
      // Adjust serial numbers array size
      const currentSerials = [...detail.serialNumbers];
      if (qty > currentSerials.length) {
        detail.serialNumbers = [...currentSerials, ...Array(qty - currentSerials.length).fill('')];
      } else {
        detail.serialNumbers = currentSerials.slice(0, qty);
      }
    }

    detail.subtotal = detail.qty * detail.unitCost;
    newDetails[index] = detail;
    setDetails(newDetails);
  };

  const handleSerialChange = (detailIndex: number, serialIndex: number, value: string) => {
    const newDetails = [...details];
    const serials = [...newDetails[detailIndex].serialNumbers];
    serials[serialIndex] = value;
    newDetails[detailIndex].serialNumbers = serials;
    setDetails(newDetails);
  };

  const totalAmount = details.reduce((sum, d) => sum + d.subtotal, 0);
  const dueAmount = Math.max(0, totalAmount - paidAmount);
  const isValid = selectedSupplierId > 0 && selectedStaffId > 0 && details.every(d => d.productId > 0 && d.qty > 0);

  const handleSave = async () => {
    if (!isValid) return;

    try {
      const payload: PurchaseDTO = {
        supplierId: selectedSupplierId,
        staffId: selectedStaffId,
        totalAmount,
        paidAmount,
        dueAmount,
        remark,
        details: details.map(d => ({
          ...d,
          productId: Number(d.productId)
        }))
      };

      const res = await purchaseApiService.create(payload);
      if (res) {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Purchase recorded successfully',
          timer: 2000,
          showConfirmButton: false
        });
        // Reset form
        setSelectedSupplierId(0);
        setSelectedStaffId(0);
        setPaidAmount(0);
        setRemark('');
        setDetails([{ productId: 0, qty: 1, unitCost: 0, subtotal: 0, serialNumbers: [''] }]);
      }
    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'Failed to record purchase'
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">New Purchase Voucher</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Form Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShoppingCart size={12} /> Supplier
                </label>
                <select 
                  value={selectedSupplierId}
                  onChange={(e) => setSelectedSupplierId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                >
                  <option value={0}>Select Supplier</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <User size={12} /> Staff / Buyer
                </label>
                <select 
                  value={selectedStaffId}
                  onChange={(e) => setSelectedStaffId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                >
                  <option value={0}>Select Staff</option>
                  {staffs.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="border border-slate-100 rounded-xl overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-wider">
                    <th className="px-4 py-3 border-b border-slate-100">Product</th>
                    <th className="px-4 py-3 border-b border-slate-100 w-24">Qty</th>
                    <th className="px-4 py-3 border-b border-slate-100 w-32">Unit Cost</th>
                    <th className="px-4 py-3 border-b border-slate-100 w-32 text-right">Subtotal</th>
                    <th className="px-4 py-3 border-b border-slate-100 w-12"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {details.map((detail, dIndex) => (
                    <React.Fragment key={dIndex}>
                      <tr className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-3">
                          <select 
                            value={detail.productId}
                            onChange={(e) => handleDetailChange(dIndex, 'productId', Number(e.target.value))}
                            className="w-full px-2 py-1 bg-transparent border-none text-sm focus:ring-0 focus:outline-none font-medium"
                          >
                            <option value={0}>Select Product</option>
                            {products.map(p => (
                              <option key={p.id} value={p.id}>{p.name} ({p.productCode})</option>
                            ))}
                          </select>
                        </td>
                        <td className="px-4 py-3">
                          <input 
                            type="number" 
                            min="1"
                            value={detail.qty}
                            onChange={(e) => handleDetailChange(dIndex, 'qty', e.target.value)}
                            className="w-full px-2 py-1 bg-transparent border-none text-sm focus:ring-0 focus:outline-none"
                          />
                        </td>
                        <td className="px-4 py-3">
                          <input 
                            type="number" 
                            value={detail.unitCost || ''}
                            onChange={(e) => handleDetailChange(dIndex, 'unitCost', parseFloat(e.target.value) || 0)}
                            placeholder="0.00"
                            className="w-full px-2 py-1 bg-transparent border-none text-sm focus:ring-0 focus:outline-none"
                          />
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-slate-700">
                          {new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(detail.subtotal)}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button 
                            onClick={() => handleRemoveRow(dIndex)}
                            className="p-1.5 text-slate-300 hover:text-rose-500 transition-colors"
                            disabled={details.length <= 1}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                      {/* Smart Serial Input Row */}
                      {detail.productId > 0 && detail.qty > 0 && (
                        <tr className="bg-slate-50/30">
                          <td colSpan={5} className="px-4 py-3">
                            <div className="flex flex-wrap gap-2">
                              <div className="w-full flex items-center gap-2 mb-1">
                                <Hash size={12} className="text-indigo-500" />
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Serial Numbers for {detail.qty} items</span>
                              </div>
                              {detail.serialNumbers.map((sn, sIndex) => (
                                <input 
                                  key={sIndex}
                                  type="text"
                                  value={sn}
                                  onChange={(e) => handleSerialChange(dIndex, sIndex, e.target.value)}
                                  placeholder={`Serial #${sIndex + 1}`}
                                  className="px-2 py-1 bg-white border border-slate-200 rounded text-[11px] w-32 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                                />
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>

            <button 
              onClick={handleAddRow}
              className="flex items-center gap-2 px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-sm font-bold transition-all"
            >
              <Plus size={16} />
              Add Product Row
            </button>
          </div>
        </div>

        {/* Right Column: Summary & Payment */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6 sticky top-20">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <DollarSign size={16} className="text-indigo-500" />
              Purchase Summary
            </h3>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500">Total Amount</span>
                <span className="font-bold text-slate-800">
                  {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalAmount)}
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Paid Amount</label>
                <input 
                  type="number" 
                  value={paidAmount || ''}
                  onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold text-emerald-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="flex justify-between items-center text-sm pt-2 border-t border-slate-100">
                <span className="text-slate-500">Due Amount</span>
                <span className={`font-bold ${dueAmount > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                  {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(dueAmount)}
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Remark</label>
                <textarea 
                  value={remark}
                  onChange={(e) => setRemark(e.target.value)}
                  rows={3}
                  placeholder="Optional notes..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all resize-none"
                />
              </div>

              <button 
                disabled={!isValid}
                onClick={handleSave}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all shadow-lg mt-4
                  ${isValid 
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200' 
                    : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'}`}
              >
                <Save size={18} />
                Complete Purchase
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PurchaseManagement;
