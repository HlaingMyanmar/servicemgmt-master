import { api } from './api';
import { ApiResponse, PurchaseDTO } from '../types';

export const purchaseApiService = {
  getAll: async (): Promise<PurchaseDTO[]> => {
    const res = await api.get<any, ApiResponse<PurchaseDTO[]>>('/v1/purchases');
    return res.data;
  },
  
  getById: async (id: number): Promise<PurchaseDTO> => {
    const res = await api.get<any, ApiResponse<PurchaseDTO>>(`/v1/purchases/${id}`);
    return res.data;
  },

  create: async (data: PurchaseDTO): Promise<PurchaseDTO> => {
    const res = await api.post<any, ApiResponse<PurchaseDTO>>('/v1/purchases', data);
    return res.data;
  }
};
