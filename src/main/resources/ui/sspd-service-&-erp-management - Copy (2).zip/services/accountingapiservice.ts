import { api } from './api';
import { ApiResponse, AccountBalanceDTO, PaymentTransactionDTO } from '../types';

export const accountingApiService = {
  getAllBalances: async (): Promise<AccountBalanceDTO[]> => {
    const res = await api.get<any, ApiResponse<AccountBalanceDTO[]>>('/v1/account-balances');
    return res.data;
  },
  
  getAccountBalance: async (accountId: number): Promise<AccountBalanceDTO> => {
    const res = await api.get<any, ApiResponse<AccountBalanceDTO>>(`/v1/account-balances/account/${accountId}`);
    return res.data;
  },

  getAllTransactions: async (): Promise<PaymentTransactionDTO[]> => {
    const res = await api.get<any, ApiResponse<PaymentTransactionDTO[]>>('/v1/payment-transactions');
    return res.data;
  },

  getTransactionsByRef: async (refId: number, type: string): Promise<PaymentTransactionDTO[]> => {
    const res = await api.get<any, ApiResponse<PaymentTransactionDTO[]>>(`/v1/payment-transactions/reference/${refId}?type=${type}`);
    return res.data;
  }
};
