
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import RoleManagement from './pages/RoleManagement';
import PermissionManagement from './pages/PermissionManagement';
import ProductManagement from './pages/ProductManagement';
import ProductSerialManagement from './pages/ProductSerialManagement';
import BrandManagement from './pages/BrandManagement';
import CategoryManagement from './pages/CategoryManagement';
import UnitManagement from './pages/UnitManagement';
import SupplierManagement from './pages/SupplierManagement';
import CustomerManagement from './pages/CustomerManagement';
import StaffManagement from './pages/StaffManagement';
import ChartOfAccountManagement from './pages/ChartOfAccountManagement';
import PaymentMethodManagement from './pages/PaymentMethodManagement';
import Layout from './components/Layout';
import { User, AppRoute } from './types';
import { getFromSession } from './utils/storageHelper';
import { authService, setAccessToken } from './services/api';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      const savedUser = getFromSession('sspd_user');
      const refreshToken = getFromSession('sspd_refresh');
      
      if (savedUser && refreshToken) {
        try {
          const res = await authService.refresh();
          if (res.success) {
            setAccessToken(res.data.accessToken);
            setUser(JSON.parse(savedUser));
          } else {
            throw new Error("Refresh failed");
          }
        } catch (e) {
          authService.logout();
        }
      }
      setLoading(false);
    };

    initializeAuth();
  }, []);

  const handleLoginSuccess = (userData: User, token: string) => {
    setUser(userData);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route 
          path={AppRoute.LOGIN} 
          element={!user ? <Login onLoginSuccess={handleLoginSuccess} /> : <Navigate to={AppRoute.DASHBOARD} />} 
        />
        <Route 
          path={AppRoute.DASHBOARD} 
          element={user ? <Layout user={user} onLogout={handleLogout}><Dashboard /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.USERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><UserManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.ROLES} 
          element={user ? <Layout user={user} onLogout={handleLogout}><RoleManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PERMISSIONS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><PermissionManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PRODUCTS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><ProductManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PRODUCT_SERIALS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><ProductSerialManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.BRANDS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><BrandManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.CATEGORIES} 
          element={user ? <Layout user={user} onLogout={handleLogout}><CategoryManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.UNITS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><UnitManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.SUPPLIERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><SupplierManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.CUSTOMERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><CustomerManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.STAFF} 
          element={user ? <Layout user={user} onLogout={handleLogout}><StaffManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.COA} 
          element={user ? <Layout user={user} onLogout={handleLogout}><ChartOfAccountManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PAYMENT_METHODS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><PaymentMethodManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route path="*" element={<Navigate to={AppRoute.DASHBOARD} />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
