
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LogOut,
  Menu,
  X,
  ChevronDown,
  Bell,
  ShieldCheck,
  UserPlus,
  Key,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { User, AppRoute } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true); // For mobile visibility
  const [isCollapsed, setIsCollapsed] = useState(false); // For desktop width toggle
  const location = useLocation();

  const rbacItems = [
    { name: 'User Access', icon: <UserPlus size={20} />, path: AppRoute.USERS },
    { name: 'Roles', icon: <ShieldCheck size={20} />, path: AppRoute.ROLES },
    { name: 'Permissions', icon: <Key size={20} />, path: AppRoute.PERMISSIONS },
  ];

  const currentPathName = rbacItems.find(i => i.path === location.pathname)?.name || 'Management System';

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside 
        className={`bg-slate-900 text-white fixed lg:static inset-y-0 left-0 z-50 transform 
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
          ${isCollapsed ? 'lg:w-20' : 'lg:w-64'} 
          transition-all duration-300 ease-in-out flex flex-col shadow-xl overflow-hidden`}
      >
        {/* Sidebar Header with Toggle at TOP */}
        <div className={`p-5 border-b border-slate-800 flex items-center min-h-[64px] ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center font-bold text-white shrink-0 shadow-lg shadow-indigo-500/20">S</div>
            {!isCollapsed && (
              <span className="text-xl font-bold tracking-tight whitespace-nowrap animate-in fade-in slide-in-from-left-2 duration-300">
                SSPD ERP
              </span>
            )}
          </div>
          
          {/* Collapse Toggle (Visible on Desktop) */}
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>

          {/* Mobile Close Button */}
          <button className="lg:hidden text-slate-400 hover:text-white transition-colors" onClick={() => setSidebarOpen(false)}>
            <X size={20} />
          </button>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-3 py-6 overflow-y-auto overflow-x-hidden space-y-2 custom-scrollbar">
          {!isCollapsed && (
            <p className="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 truncate animate-in fade-in duration-500">
              Security & Auth
            </p>
          )}
          
          {rbacItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all group ${
                location.pathname === item.path 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              } ${isCollapsed ? 'justify-center px-0' : ''}`}
              title={isCollapsed ? item.name : ''}
            >
              <div className={`shrink-0 transition-transform duration-300 ${isCollapsed ? 'group-hover:scale-110' : ''}`}>
                {item.icon}
              </div>
              {!isCollapsed && (
                <span className="font-medium whitespace-nowrap animate-in fade-in slide-in-from-left-2 duration-300">
                  {item.name}
                </span>
              )}
            </Link>
          ))}
        </nav>

        {/* User Info (Visible only when expanded) */}
        {!isCollapsed && (
           <div className="p-4 bg-slate-800/30 border-t border-slate-800 animate-in fade-in duration-500">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold border border-indigo-500/30">
                  {user.username.charAt(0).toUpperCase()}
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold text-slate-200 truncate">{user.username}</p>
                  <p className="text-[9px] text-slate-500 uppercase tracking-tighter truncate font-semibold">
                    {user.roles[0]?.replace('ROLE_', '') || 'Authorized'}
                  </p>
                </div>
             </div>
           </div>
        )}

        {/* Logout Section */}
        <div className="p-3 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className={`flex items-center gap-4 px-4 py-3 w-full text-left rounded-xl text-rose-400 hover:bg-rose-500/10 transition-all group ${isCollapsed ? 'justify-center px-0' : ''}`}
            title={isCollapsed ? "Sign Out" : ""}
          >
            <div className={`shrink-0 transition-transform duration-300 ${isCollapsed ? 'group-hover:scale-110' : ''}`}>
              <LogOut size={20} />
            </div>
            {!isCollapsed && (
              <span className="font-medium whitespace-nowrap animate-in fade-in slide-in-from-left-2 duration-300">
                Sign Out
              </span>
            )}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-40 shadow-sm backdrop-blur-md bg-white/80">
          <div className="flex items-center gap-4">
            <button 
              className="p-2 hover:bg-slate-100 rounded-lg lg:hidden transition-colors" 
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="flex flex-col">
              <h1 className="text-lg font-bold text-slate-800 hidden sm:block leading-tight">
                {currentPathName}
              </h1>
              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                <span>Enterprise</span>
                <span>/</span>
                <span className="text-indigo-500 font-bold">{currentPathName.split(' ')[0]}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-xl relative transition-all group">
              <Bell size={20} className="group-hover:rotate-12 transition-transform" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white ring-2 ring-rose-500/20"></span>
            </button>
            <div className="h-8 w-px bg-slate-200 mx-1"></div>
            <div className="flex items-center gap-3 cursor-pointer hover:bg-slate-100 p-1.5 pr-3 rounded-xl transition-all group border border-transparent hover:border-slate-200">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold uppercase shrink-0 transition-transform group-hover:scale-105">
                {user.username.charAt(0)}
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-bold text-slate-800 leading-none">{user.username}</p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold mt-1">
                  {user.roles[0]?.replace('ROLE_', '') || 'User'}
                </p>
              </div>
              <ChevronDown size={14} className="text-slate-400 group-hover:translate-y-0.5 transition-transform" />
            </div>
          </div>
        </header>

        {/* Content Area - Fixed width removed to allow full left alignment */}
        <main className="flex-1 p-6 overflow-y-auto bg-slate-50/50 custom-scrollbar transition-all duration-300">
          <div className="w-full">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 z-40 lg:hidden backdrop-blur-sm animate-in fade-in duration-300"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
          height: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}} />
    </div>
  );
};

export default Layout;
