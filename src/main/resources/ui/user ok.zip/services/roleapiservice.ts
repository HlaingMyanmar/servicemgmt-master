
import axios from 'https://esm.sh/axios@1.7.9';
import { RoleDTO, ApiResponse } from '../types';
import { getCookie } from '../utils/cookieHelper';
import { BASE_URL } from './api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = getCookie('sspd_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  response => response.data,
  error => Promise.reject(error.response?.data || { success: false, message: error.message })
);

export const roleService = {
  getAll: async (): Promise<RoleDTO[]> => {
    const response = await api.get<any, ApiResponse<RoleDTO[]>>('/v1/roles');
    return response.data;
  },

  getById: (id: number) => 
    api.get<any, ApiResponse<RoleDTO>>(`/v1/roles/${id}`).then((res: any) => res.data),

  create: (role: Partial<RoleDTO>) => 
    api.post<any, ApiResponse<RoleDTO>>('/v1/roles', role).then((res: any) => res.data),

  update: (id: number, role: Partial<RoleDTO>) => 
    api.put<any, ApiResponse<RoleDTO>>(`/v1/roles/${id}`, role).then((res: any) => res.data),

  delete: (id: number) => 
    api.delete<any, ApiResponse<void>>(`/v1/roles/${id}`).then((res: any) => res.data),

  assignPermissions: (roleId: number, permissionIds: number[]) => 
    api.put<any, ApiResponse<void>>(`/v1/roles/${roleId}/permissions`, permissionIds).then((res: any) => res.data)
};
