
import axios from 'https://esm.sh/axios@1.7.9';
import { PermissionDTO, ApiResponse } from '../types';
import { getCookie } from '../utils/cookieHelper';
import { BASE_URL } from './api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = getCookie('sspd_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  response => response.data,
  error => Promise.reject(error.response?.data || { success: false, message: error.message })
);

export const permissionService = {
  getAll: async (): Promise<PermissionDTO[]> => {
    const res = await api.get<any, ApiResponse<PermissionDTO[]>>('/v1/permissions');
    return res.data;
  },

  getById: (id: number) => api.get<any, ApiResponse<PermissionDTO>>(`/v1/permissions/${id}`).then((res: any) => res.data),
  
  create: (permission: Omit<PermissionDTO, 'id'>) => 
    api.post<any, ApiResponse<PermissionDTO>>('/v1/permissions', permission).then((res: any) => res.data),
  
  update: (id: number, permission: Partial<PermissionDTO>) => 
    api.put<any, ApiResponse<PermissionDTO>>(`/v1/permissions/${id}`, permission).then((res: any) => res.data),
  
  delete: (id: number) => api.delete<any, ApiResponse<void>>(`/v1/permissions/${id}`).then((res: any) => res.data)
};
