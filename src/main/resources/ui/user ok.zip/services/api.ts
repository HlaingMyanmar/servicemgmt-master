
import axios from 'https://esm.sh/axios@1.7.9';
import { AuthResponse, User, DashboardStats, ApiResponse } from '../types';
import { getCookie, eraseCookie } from '../utils/cookieHelper';

// Centralized URLs
export const BASE_URL = 'http://localhost:8080/api';
export const WS_URL = 'http://localhost:8080/ws-clinic';

/**
 * Axios Instance Configuration
 */
const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

/**
 * Request Interceptor for Authorization
 */
api.interceptors.request.use(config => {
  const token = getCookie('sspd_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

/**
 * Response Interceptor for standardizing SSPD API Responses
 */
api.interceptors.response.use(
  response => response.data,
  error => {
    const apiError = error.response?.data || { success: false, message: error.message };
    return Promise.reject(apiError);
  }
);

export const authService = {
  login: async (usernameOremail: string, password: string): Promise<ApiResponse<AuthResponse>> => {
    return api.post('/v1/auth/login', { usernameOremail, password });
  },

  logout: () => {
    eraseCookie('sspd_token');
    eraseCookie('sspd_user');
  },

  getCurrentUser: (): User | null => {
    const saved = getCookie('sspd_user');
    return saved ? JSON.parse(saved) : null;
  }
};

export const dashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    const response = await api.get<any, ApiResponse<DashboardStats>>('/v1/dashboard/stats');
    return response.data;
  }
};

export const entityService = {
  getServices: () => api.get<any, ApiResponse<any[]>>('/v1/services').then((res: any) => res.data),
  getProducts: () => api.get<any, ApiResponse<any[]>>('/v1/products').then((res: any) => res.data),
  getCustomers: () => api.get<any, ApiResponse<any[]>>('/v1/customers').then((res: any) => res.data),
  getStaff: () => api.get<any, ApiResponse<any[]>>('/v1/staff').then((res: any) => res.data),
};
