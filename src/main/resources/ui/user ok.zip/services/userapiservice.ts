
import axios from 'https://esm.sh/axios@1.7.9';
import { UserDTO, ApiResponse } from '../types';
import { getCookie } from '../utils/cookieHelper';
import { BASE_URL } from './api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = getCookie('sspd_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  response => response.data,
  error => Promise.reject(error.response?.data || { success: false, message: error.message })
);

export const userService = {
  getAll: async (): Promise<UserDTO[]> => {
    const response = await api.get<any, ApiResponse<UserDTO[]>>('/v1/user');
    return response.data;
  },

  getById: (id: number) => 
    api.get<any, ApiResponse<UserDTO>>(`/v1/user/${id}`).then((res: any) => res.data),

  create: (user: Partial<UserDTO & { password?: string }>) => 
    api.post<any, ApiResponse<UserDTO>>('/v1/user', user).then((res: any) => res.data),

  update: (id: number, user: Partial<UserDTO>) => 
    api.put<any, ApiResponse<UserDTO>>(`/v1/user/${id}`, user).then((res: any) => res.data),

  delete: (id: number) => 
    api.delete<any, ApiResponse<void>>(`/v1/user/${id}`).then((res: any) => res.data),

  assignRoles: (userId: number, roleIds: number[]) => 
    api.put<any, ApiResponse<void>>(`/v1/user/${userId}/role`, roleIds).then((res: any) => res.data)
};
