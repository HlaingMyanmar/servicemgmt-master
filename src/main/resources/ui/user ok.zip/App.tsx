
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import RoleManagement from './pages/RoleManagement';
import PermissionManagement from './pages/PermissionManagement';
import Layout from './components/Layout';
import { User, AppRoute } from './types';
import { setCookie, getCookie, eraseCookie } from './utils/cookieHelper';
import { authService } from './services/api';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Restore session from cookies instead of clearing it
    const savedUser = getCookie('sspd_user');
    const token = getCookie('sspd_token');
    
    if (savedUser && token) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Session restore failed", e);
        eraseCookie('sspd_user');
        eraseCookie('sspd_token');
      }
    }
    
    setLoading(false);
  }, []);

  const handleLoginSuccess = (userData: User, token: string) => {
    setUser(userData);
    // Store in session cookies (valid for 1 day in this case, adjust as needed)
    setCookie('sspd_user', JSON.stringify(userData), 1);
    setCookie('sspd_token', token, 1);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route 
          path={AppRoute.LOGIN} 
          element={!user ? <Login onLoginSuccess={handleLoginSuccess} /> : <Navigate to={AppRoute.DASHBOARD} />} 
        />
        <Route 
          path={AppRoute.DASHBOARD} 
          element={user ? <Layout user={user} onLogout={handleLogout}><Dashboard /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.USERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><UserManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.ROLES} 
          element={user ? <Layout user={user} onLogout={handleLogout}><RoleManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PERMISSIONS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><PermissionManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route path="*" element={<Navigate to={AppRoute.DASHBOARD} />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
