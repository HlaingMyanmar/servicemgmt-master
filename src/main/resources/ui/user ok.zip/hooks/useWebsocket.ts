
import { useEffect, useRef } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { WS_URL } from '../services/api';
import { getCookie } from '../utils/cookieHelper';

/**
 * Custom hook to manage STOMP over WebSocket connection.
 * Includes Authorization headers for secure communication.
 */
export const useWebsocket = (topic: string, onMessage: (message: string) => void) => {
  const messageHandlerRef = useRef(onMessage);

  useEffect(() => {
    messageHandlerRef.current = onMessage;
  }, [onMessage]);

  useEffect(() => {
    const token = getCookie('sspd_token');
    
    console.log(`[WS-INIT] Target: ${WS_URL}, Topic: ${topic}`);

    const SockJSConstructor = (SockJS as any).default || SockJS;

    const client = new Client({
      // We use webSocketFactory for SockJS compatibility with Spring Boot
      webSocketFactory: () => {
        return new SockJSConstructor(WS_URL);
      },
      // Pass JWT token in connectHeaders for STOMP authentication
      connectHeaders: {
        Authorization: token ? `Bearer ${token}` : '',
      },
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
      debug: (msg) => {
        if (msg.includes('CONNECTED') || msg.includes('ERROR') || msg.includes('STOMP')) {
          console.debug(`[WS-STOMP] ${msg}`);
        }
      },
    });

    client.onConnect = (frame) => {
      console.info(`[WS-READY] Connected successfully to ${topic}`);
      client.subscribe(topic, (message) => {
        if (messageHandlerRef.current) {
          messageHandlerRef.current(message.body);
        }
      });
    };

    client.onStompError = (frame) => {
      console.error('[WS-STOMP-ERROR] Protocol error:', frame.headers['message']);
      console.debug('[WS-STOMP-DETAILS]', frame.body);
    };

    client.onWebSocketError = (event) => {
      console.error('[WS-NET-ERROR] WebSocket connection failed.');
      console.error('Note: If you see 403 Forbidden, ensure Backend permits "/ws-clinic/**" in SecurityConfig.');
    };

    client.onWebSocketClose = (event) => {
      if (event.code === 1006) {
        console.warn('[WS-CLOSE] Connection abnormal (1006). This is often a CORS or Security 403 issue.');
      }
    };

    try {
      client.activate();
    } catch (err) {
      console.error("[WS-FATAL] Client activation failed:", err);
    }

    return () => {
      if (client.active) {
        console.log(`[WS-EXIT] Deactivating for ${topic}`);
        client.deactivate();
      }
    };
  }, [topic]); 
};
