
import React, { useEffect, useState, useCallback } from 'react';
import { permissionService } from '../services/permissionapiservice';
import { PermissionDTO } from '../types';
import { Loader2, Key, Search, Trash2, Edit2, Wifi, Plus, X, Save } from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const PermissionManagement: React.FC = () => {
  const [permissions, setPermissions] = useState<PermissionDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPermission, setEditingPermission] = useState<PermissionDTO | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });
  const [saving, setSaving] = useState(false);

  const fetchPermissions = useCallback(async () => {
    try {
      const data = await permissionService.getAll();
      setPermissions(data);
    } catch (error) {
      console.error("Failed to load permissions", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPermissions();
  }, [fetchPermissions]);

  // WebSocket Listener with a stable callback
  const handleWsMessage = useCallback((message: string) => {
    console.log('[Permission-Sync] Received update signal');
    setWsStatus('online');
    fetchPermissions();
    // Reset sync badge after 5 seconds
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchPermissions]);

  useWebsocket('/topic/permissions', handleWsMessage);

  const handleOpenModal = (permission?: PermissionDTO) => {
    if (permission) {
      setEditingPermission(permission);
      setFormData({ name: permission.name, description: permission.description || '' });
    } else {
      setEditingPermission(null);
      setFormData({ name: '', description: '' });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingPermission) {
        await permissionService.update(editingPermission.id, formData);
        Swal.fire({
          icon: 'success',
          title: 'Updated',
          text: 'Permission updated successfully',
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });
      } else {
        await permissionService.create(formData);
        Swal.fire({
          icon: 'success',
          title: 'Created',
          text: 'New permission added',
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });
      }
      setIsModalOpen(false);
      fetchPermissions();
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Failed to save permission', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: "This permission will be permanently removed!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Yes, delete it!'
    });

    if (result.isConfirmed) {
      try {
        await permissionService.delete(id);
        Swal.fire('Deleted!', 'Permission removed.', 'success');
        fetchPermissions();
      } catch (error: any) {
        Swal.fire('Failed', error.message || 'Error deleting', 'error');
      }
    }
  };

  const filteredPermissions = permissions.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (p.description && p.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="animate-spin text-indigo-600" size={40} />
        <p className="text-slate-500 font-medium">Synchronizing Repository...</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 relative min-h-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Permission Repository</h2>
            {/* Added Permission Count Badge */}
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold border border-indigo-200 shadow-sm">
              Total: {permissions.length}
            </span>
            {wsStatus === 'online' && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 animate-pulse">
                <Wifi size={10} /> Live Sync Active
              </span>
            )}
          </div>
          <p className="text-slate-500 text-sm">Manage system authorization keys for fine-grained security control.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search keys..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500 outline-none text-sm shadow-sm transition-all w-64"
            />
          </div>
          <button 
            onClick={() => handleOpenModal()}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
          >
            <Plus size={18} /> Add Entry
          </button>
        </div>
      </div>

      {/* Grid: Adaptive for wide screen and sidebar collapse */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 gap-4 transition-all duration-300">
        {filteredPermissions.map(permission => (
          <div key={permission.id} className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm hover:border-indigo-200 hover:shadow-md transition-all group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            
            <div className="flex items-start justify-between">
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 mb-4 shadow-sm border border-indigo-100 group-hover:scale-110 transition-transform">
                <Key size={20} />
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 translate-y-[-10px] group-hover:translate-y-0 transition-all">
                <button 
                  onClick={() => handleOpenModal(permission)}
                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  <Edit2 size={14} />
                </button>
                <button 
                  onClick={() => handleDelete(permission.id)}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
            
            <h4 className="font-bold text-slate-800 text-sm mb-1 tracking-tight truncate">{permission.name}</h4>
            <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 min-h-[32px]">
              {permission.description || `Grants system authority for ${permission.name.toLowerCase()}`}
            </p>
            
            <div className="mt-4 flex items-center justify-between pt-4 border-t border-slate-50">
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">ID: #{permission.id}</span>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Enterprise Key</span>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Key size={20} /></div>
                <h3 className="font-bold text-slate-800">{editingPermission ? 'Update Permission' : 'New Permission'}</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full"><X size={20} className="text-slate-400" /></button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">Name <span className="text-rose-500">*</span></label>
                <input
                  type="text" required placeholder="e.g. CAN_EDIT_SALES"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value.toUpperCase().replace(/\s/g, '_')})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Description</label>
                <textarea
                  rows={3} placeholder="Key usage description..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all resize-none"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 px-4 py-3 rounded-xl bg-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 disabled:opacity-70 transition-all flex items-center justify-center gap-2 active:scale-95">
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  {editingPermission ? 'Update Key' : 'Create Key'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PermissionManagement;
