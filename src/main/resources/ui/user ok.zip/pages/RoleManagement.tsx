
import React, { useEffect, useState, useCallback } from 'react';
import { roleService } from '../services/roleapiservice';
import { permissionService } from '../services/permissionapiservice';
import { RoleDTO, PermissionDTO } from '../types';
import { 
  Loader2, Plus, ShieldCheck, Key, Settings2, Search, 
  Trash2, Edit2, Wifi, Save, X, CheckSquare, Square
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const RoleManagement: React.FC = () => {
  const [roles, setRoles] = useState<RoleDTO[]>([]);
  const [allPermissions, setAllPermissions] = useState<PermissionDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<RoleDTO | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });
  const [selectedPermissionIds, setSelectedPermissionIds] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [roleData, permData] = await Promise.all([
        roleService.getAll(),
        permissionService.getAll()
      ]);
      setRoles(roleData);
      setAllPermissions(permData);
    } catch (error) {
      console.error("Failed to load RBAC data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // WebSocket sync for roles
  const handleWsMessage = useCallback((message: string) => {
    console.log('[Role-Sync] Signal received:', message);
    setWsStatus('online');
    fetchData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchData]);

  useWebsocket('/topic/role', handleWsMessage);

  const handleOpenRoleModal = (role?: RoleDTO) => {
    if (role) {
      setEditingRole(role);
      setFormData({ name: role.name, description: role.description || '' });
    } else {
      setEditingRole(null);
      setFormData({ name: 'ROLE_', description: '' });
    }
    setIsModalOpen(true);
  };

  const handleOpenAssignModal = (role: RoleDTO) => {
    setEditingRole(role);
    setSelectedPermissionIds(role.permissions.map(p => p.id));
    setIsAssignModalOpen(true);
  };

  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingRole) {
        await roleService.update(editingRole.id, formData);
        Swal.fire({ icon: 'success', title: 'Updated', text: 'Role modified', toast: true, position: 'top-end', showConfirmButton: false, timer: 3000 });
      } else {
        await roleService.create(formData);
        Swal.fire({ icon: 'success', title: 'Created', text: 'New role added', toast: true, position: 'top-end', showConfirmButton: false, timer: 3000 });
      }
      setIsModalOpen(false);
      fetchData();
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Action failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleAssignPermissions = async () => {
    if (!editingRole) return;
    setSaving(true);
    try {
      await roleService.assignPermissions(editingRole.id, selectedPermissionIds);
      Swal.fire({ icon: 'success', title: 'Success', text: 'Permissions synced with role', toast: true, position: 'top-end', showConfirmButton: false, timer: 3000 });
      setIsAssignModalOpen(false);
      fetchData();
    } catch (error: any) {
      Swal.fire('Failed', error.message || 'Sync failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteRole = async (id: number) => {
    const result = await Swal.fire({
      title: 'Delete Role?',
      text: "Users assigned to this role might lose access!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, Delete it'
    });

    if (result.isConfirmed) {
      try {
        await roleService.delete(id);
        Swal.fire('Removed', 'Role deleted.', 'success');
        fetchData();
      } catch (error: any) {
        Swal.fire('Denied', error.message, 'error');
      }
    }
  };

  const togglePermission = (id: number) => {
    setSelectedPermissionIds(prev => 
      prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]
    );
  };

  const filteredRoles = roles.filter(r => 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (r.description && r.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="animate-spin text-indigo-600" size={40} />
        <p className="text-slate-500 font-medium">Loading Security Matrix...</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 min-h-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-slate-800 tracking-tight">System Roles</h2>
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold border border-indigo-200">
              Total: {roles.length}
            </span>
            {wsStatus === 'online' && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 animate-pulse">
                <Wifi size={10} /> Live
              </span>
            )}
          </div>
          <p className="text-slate-500 text-sm">Define and manage permission sets for different job functions.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" placeholder="Search roles..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/5 outline-none text-sm shadow-sm w-64 transition-all"
            />
          </div>
          <button 
            onClick={() => handleOpenRoleModal()}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
          >
            <Plus size={18} /> Create Role
          </button>
        </div>
      </div>

      {/* Roles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
        {filteredRoles.map(role => (
          <div key={role.id} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-all relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 translate-x-2 group-hover:translate-x-0 transition-all flex gap-1">
              <button 
                onClick={() => handleOpenRoleModal(role)}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                title="Edit Role Details"
              >
                <Edit2 size={16} />
              </button>
              <button 
                onClick={() => handleDeleteRole(role.id)}
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                title="Delete Role"
              >
                <Trash2 size={16} />
              </button>
            </div>
            
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:scale-110 transition-transform">
                <ShieldCheck size={28} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 tracking-tight">{role.name}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">ID: #{role.id}</p>
              </div>
            </div>

            <p className="text-sm text-slate-600 mb-6 line-clamp-2 min-h-[40px] leading-relaxed">
              {role.description || "No specific description provided for this security clearance level."}
            </p>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] border-b border-slate-50 pb-2">
                <span>Access Keys</span>
                <span className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full">{role.permissions.length}</span>
              </div>
              <div className="flex flex-wrap gap-1.5 min-h-[60px]">
                {role.permissions.slice(0, 5).map(p => (
                  <span key={p.id} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-50 text-slate-500 text-[10px] font-bold border border-slate-100 shadow-sm">
                    <Key size={10} className="text-slate-400" /> {p.name}
                  </span>
                ))}
                {role.permissions.length > 5 && (
                  <span className="text-[10px] text-indigo-500 font-bold py-1 ml-1">+{role.permissions.length - 5} more</span>
                )}
                {role.permissions.length === 0 && <span className="text-[10px] text-slate-400 italic">Unassigned Access</span>}
              </div>
              
              <button 
                onClick={() => handleOpenAssignModal(role)}
                className="w-full py-2 bg-slate-50 hover:bg-indigo-50 text-slate-500 hover:text-indigo-600 rounded-xl text-xs font-bold transition-all border border-slate-100 flex items-center justify-center gap-2 group/btn"
              >
                <Settings2 size={14} className="group-hover/btn:rotate-45 transition-transform" />
                Manage Permissions
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Role Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><ShieldCheck size={20} /></div>
                <h3 className="font-bold text-slate-800">{editingRole ? 'Update Role' : 'Create New Role'}</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-400" /></button>
            </div>

            <form onSubmit={handleSaveRole} className="p-6 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Role Name <span className="text-rose-500">*</span></label>
                <input
                  type="text" required placeholder="e.g. ROLE_SALES_OPERATOR"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value.toUpperCase().replace(/\s/g, '_')})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Functional Description</label>
                <textarea
                  rows={3} placeholder="Describe the job functions for this role..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all resize-none"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 px-4 py-3 rounded-xl bg-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 active:scale-95 transition-all">
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  Save Role
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Permission Assignment Modal */}
      {isAssignModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 max-h-[85vh] flex flex-col animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Key size={20} /></div>
                <div>
                  <h3 className="font-bold text-slate-800">Permissions for {editingRole?.name}</h3>
                  <p className="text-xs text-slate-400 font-medium">Select access keys to grant to this role</p>
                </div>
              </div>
              <button onClick={() => setIsAssignModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-400" /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {allPermissions.map(perm => {
                  const isSelected = selectedPermissionIds.includes(perm.id);
                  return (
                    <button 
                      key={perm.id}
                      onClick={() => togglePermission(perm.id)}
                      className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all text-left group ${
                        isSelected 
                          ? 'bg-indigo-50 border-indigo-200 text-indigo-700' 
                          : 'bg-white border-slate-100 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <div className={`transition-colors ${isSelected ? 'text-indigo-600' : 'text-slate-300'}`}>
                        {isSelected ? <CheckSquare size={20} /> : <Square size={20} />}
                      </div>
                      <div>
                        <p className="text-sm font-bold leading-tight">{perm.name}</p>
                        <p className={`text-[10px] mt-0.5 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`}>
                          {perm.description || 'No description available'}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <div className="text-xs font-bold text-slate-500">
                {selectedPermissionIds.length} Keys Selected
              </div>
              <div className="flex gap-3">
                <button onClick={() => setIsAssignModalOpen(false)} className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-white transition-colors">Cancel</button>
                <button 
                  onClick={handleAssignPermissions}
                  disabled={saving}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  Apply Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoleManagement;
