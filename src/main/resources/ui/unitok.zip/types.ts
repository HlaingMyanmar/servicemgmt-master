
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

export interface AuthResponse {
  accessToken: string;
  username: string;
  roles: string[];
  permissions: string[];
}

export interface User {
  username: string;
  roles: string[];
  permissions: string[];
}

export interface PermissionDTO {
  id: number;
  name: string;
  description?: string;
}

export interface RoleDTO {
  id: number;
  name: string;
  description?: string;
  permissions: PermissionDTO[];
}

export interface UserDTO {
  id: number;
  username: string;
  email: string;
  authProvider: string;
  isActive: boolean;
  roles: string[];
}

export interface BrandDTO {
  id: number;
  name: string;
  isActive: boolean;
}

export interface UnitDTO {
  id: number;
  unitName: string;
  description?: string;
}

export interface CategoryDTO {
  id: number;
  name: string;
  description?: string;
  active: boolean;
  parentId: number | null;
  parentName?: string;
  children?: CategoryDTO[];
}

export interface DashboardStats {
  totalSales: number;
  totalPurchases: number;
  totalServices: number;
  totalCustomers: number;
  recentSales: SaleSummary[];
}

export interface SaleSummary {
  id: number;
  saleCode: string;
  customerName: string;
  amount: number;
  date: string;
  status: 'Paid' | 'Partial' | 'Pending';
}

export enum AppRoute {
  LOGIN = '/login',
  DASHBOARD = '/',
  USERS = '/rbac/users',
  ROLES = '/rbac/roles',
  PERMISSIONS = '/rbac/permissions',
  BRANDS = '/inventory/brands',
  CATEGORIES = '/inventory/categories',
  UNITS = '/inventory/units'
}
