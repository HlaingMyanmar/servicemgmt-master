
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import RoleManagement from './pages/RoleManagement';
import PermissionManagement from './pages/PermissionManagement';
import Layout from './components/Layout';
import { User, AppRoute } from './types';
import { getFromSession, removeFromSession } from './utils/storageHelper';
import { authService, setAccessToken } from './services/api';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      const savedUser = getFromSession('sspd_user');
      const refreshToken = getFromSession('sspd_refresh');
      
      if (savedUser && refreshToken) {
        try {
          // Attempt silent refresh to get a fresh Access Token into Memory
          const res = await authService.refresh();
          if (res.success) {
            setAccessToken(res.data.accessToken);
            setUser(JSON.parse(savedUser));
          } else {
            throw new Error("Refresh failed");
          }
        } catch (e) {
          console.warn("Session restoration failed, clearing stale session.");
          authService.logout();
        }
      }
      setLoading(false);
    };

    initializeAuth();
  }, []);

  const handleLoginSuccess = (userData: User, token: string) => {
    setUser(userData);
    // Note: setAccessToken is already handled inside authService.login
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-indigo-600"></div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Securing Connection...</p>
        </div>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route 
          path={AppRoute.LOGIN} 
          element={!user ? <Login onLoginSuccess={handleLoginSuccess} /> : <Navigate to={AppRoute.DASHBOARD} />} 
        />
        <Route 
          path={AppRoute.DASHBOARD} 
          element={user ? <Layout user={user} onLogout={handleLogout}><Dashboard /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.USERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><UserManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.ROLES} 
          element={user ? <Layout user={user} onLogout={handleLogout}><RoleManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PERMISSIONS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><PermissionManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route path="*" element={<Navigate to={AppRoute.DASHBOARD} />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
