
import React, { useEffect, useState, useCallback } from 'react';
import { userService } from '../services/userapiservice';
import { roleService } from '../services/roleapiservice';
import { UserDTO, RoleDTO } from '../types';
import { 
  Loader2, Plus, Search, Shield, Mail, CheckCircle, XCircle, 
  Trash2, Edit2, Wifi, Save, X, MoreHorizontal, UserCheck, 
  UserPlus, Key, Eye, EyeOff
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<UserDTO[]>([]);
  const [availableRoles, setAvailableRoles] = useState<RoleDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserDTO | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({ username: '', email: '', password: '', isActive: true });
  const [selectedRoleIds, setSelectedRoleIds] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [userData, rolesData] = await Promise.all([
        userService.getAll(),
        roleService.getAll()
      ]);
      setUsers(userData);
      setAvailableRoles(rolesData);
    } catch (error) {
      console.error("Failed to load user data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleWsMessage = useCallback((message: string) => {
    console.log('[User-Sync] Socket update:', message);
    setWsStatus('online');
    fetchData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchData]);

  useWebsocket('/topic/user', handleWsMessage);

  const handleOpenUserModal = (user?: UserDTO) => {
    if (user) {
      setEditingUser(user);
      setFormData({ username: user.username, email: user.email, password: '', isActive: user.isActive });
    } else {
      setEditingUser(null);
      setFormData({ username: '', email: '', password: '', isActive: true });
    }
    setShowPassword(false);
    setIsModalOpen(true);
  };

  const handleOpenRoleModal = (user: UserDTO) => {
    setEditingUser(user);
    const currentIds = availableRoles
      .filter(r => user.roles.includes(r.name))
      .map(r => r.id);
    setSelectedRoleIds(currentIds);
    setIsRoleModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    // Create a payload that excludes password if it's empty during edit
    const payload = { ...formData };
    if (editingUser && !payload.password) {
      delete (payload as any).password;
    }

    try {
      if (editingUser) {
        await userService.update(editingUser.id, payload);
        Swal.fire({ icon: 'success', title: 'User Updated', toast: true, position: 'top-end', showConfirmButton: false, timer: 2000 });
      } else {
        await userService.create(payload);
        Swal.fire({ icon: 'success', title: 'User Created', toast: true, position: 'top-end', showConfirmButton: false, timer: 2000 });
      }
      setIsModalOpen(false);
      fetchData();
    } catch (error: any) {
      Swal.fire('Failed', error.message || 'System error', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleAssignRoles = async () => {
    if (!editingUser) return;
    setSaving(true);
    try {
      await userService.assignRoles(editingUser.id, selectedRoleIds);
      Swal.fire({ icon: 'success', title: 'Roles Synchronized', toast: true, position: 'top-end', showConfirmButton: false, timer: 2000 });
      setIsRoleModalOpen(false);
      fetchData();
    } catch (error: any) {
      Swal.fire('Error', 'Role assignment failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteUser = async (id: number) => {
    const result = await Swal.fire({
      title: 'Deactivate Account?',
      text: "This user will lose all system access immediately.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Confirm Deletion'
    });

    if (result.isConfirmed) {
      try {
        await userService.delete(id);
        Swal.fire('Success', 'User removed from directory.', 'success');
        fetchData();
      } catch (error: any) {
        Swal.fire('Denied', error.message, 'error');
      }
    }
  };

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="animate-spin text-indigo-600" size={40} />
        <p className="text-slate-500 font-medium">Fetching Identity Directory...</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 min-h-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Identity & Access</h2>
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold border border-indigo-200">
              Total: {users.length}
            </span>
            {wsStatus === 'online' && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 animate-pulse">
                <Wifi size={10} /> Syncing
              </span>
            )}
          </div>
          <p className="text-slate-500 text-sm">Manage user accounts and their associated security roles.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" placeholder="Search identities..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/5 outline-none text-sm shadow-sm w-64 transition-all"
            />
          </div>
          <button 
            onClick={() => handleOpenUserModal()}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
          >
            <UserPlus size={18} /> New Account
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-5">
        {filteredUsers.map(user => (
          <div key={user.id} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-all relative group overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${user.isActive ? 'bg-indigo-500' : 'bg-slate-300'}`}></div>
            
            <div className="flex justify-between items-start mb-6">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-xl font-black text-slate-400 uppercase tracking-tighter">
                {user.username.charAt(0)}
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => handleOpenUserModal(user)}
                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  <Edit2 size={16} />
                </button>
                <button 
                  onClick={() => handleDeleteUser(user.id)}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <div className="space-y-1 mb-6">
              <h3 className="font-bold text-slate-800 tracking-tight flex items-center gap-2">
                {user.username}
                {user.isActive && <CheckCircle size={14} className="text-emerald-500" />}
              </h3>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <Mail size={12} />
                {user.email}
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">
                <span>Roles & Authority</span>
                <span className="text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-full">{user.roles.length}</span>
              </div>
              <div className="flex flex-wrap gap-1.5 min-h-[48px]">
                {user.roles.map(role => (
                  <span key={role} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50/50 text-indigo-600 text-[10px] font-bold border border-indigo-100/50">
                    <Shield size={10} /> {role.replace('ROLE_', '')}
                  </span>
                ))}
                {user.roles.length === 0 && <span className="text-[10px] text-slate-400 italic">No Roles Assigned</span>}
              </div>

              <button 
                onClick={() => handleOpenRoleModal(user)}
                className="w-full py-2.5 bg-slate-50 hover:bg-indigo-600 text-slate-500 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-100 flex items-center justify-center gap-2"
              >
                <Key size={14} />
                Security Access
              </button>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-300 uppercase">Provider: {user.authProvider}</span>
              <span className={`text-[10px] font-bold uppercase ${user.isActive ? 'text-emerald-500' : 'text-slate-400'}`}>
                {user.isActive ? 'Status: Active' : 'Status: Locked'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><UserCheck size={20} /></div>
                <h3 className="font-bold text-slate-800">{editingUser ? 'Edit Identity' : 'Create New Account'}</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-400" /></button>
            </div>

            <form onSubmit={handleSaveUser} className="p-6 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Username <span className="text-rose-500">*</span></label>
                <input
                  type="text" required placeholder="Account identifier..."
                  value={formData.username}
                  onChange={(e) => setFormData({...formData, username: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 outline-none text-sm transition-all"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Email Address <span className="text-rose-500">*</span></label>
                <input
                  type="email" required placeholder="corporate@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 outline-none text-sm transition-all"
                />
              </div>
              
              <div className="space-y-1.5">
                <div className="flex justify-between items-end">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Password {!editingUser && <span className="text-rose-500">*</span>}
                  </label>
                  {editingUser && <span className="text-[10px] text-indigo-500 font-bold uppercase italic">Leave blank to keep current</span>}
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'} 
                    required={!editingUser}
                    placeholder={editingUser ? "•••••••• (optional)" : "••••••••"}
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 outline-none text-sm transition-all"
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, isActive: !formData.isActive})}
                  className={`w-10 h-6 rounded-full transition-colors relative ${formData.isActive ? 'bg-indigo-500' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.isActive ? 'left-5' : 'left-1'}`}></div>
                </button>
                <span className="text-xs font-bold text-slate-600 uppercase">Account Status: {formData.isActive ? 'Active' : 'Disabled'}</span>
              </div>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 px-4 py-3 rounded-xl bg-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  Save Identity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Role Assignment Modal */}
      {isRoleModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 max-h-[85vh] flex flex-col animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Shield size={20} /></div>
                <div>
                  <h3 className="font-bold text-slate-800">Authority Delegation</h3>
                  <p className="text-xs text-slate-400 font-medium">Assign roles to user: <span className="text-indigo-600 font-bold">{editingUser?.username}</span></p>
                </div>
              </div>
              <button onClick={() => setIsRoleModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-400" /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-3 custom-scrollbar">
              {availableRoles.map(role => {
                const isSelected = selectedRoleIds.includes(role.id);
                return (
                  <button 
                    key={role.id}
                    onClick={() => setSelectedRoleIds(prev => isSelected ? prev.filter(id => id !== role.id) : [...prev, role.id])}
                    className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all text-left group ${
                      isSelected 
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-700' 
                        : 'bg-white border-slate-100 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg transition-colors ${isSelected ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-50 text-slate-400'}`}>
                        <Shield size={20} />
                      </div>
                      <div>
                        <p className="font-bold text-sm leading-tight">{role.name}</p>
                        <p className="text-[10px] text-slate-400 font-medium mt-0.5">{role.description || 'Access level definition.'}</p>
                      </div>
                    </div>
                    {isSelected && <CheckCircle size={20} className="text-indigo-600" />}
                  </button>
                );
              })}
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{selectedRoleIds.length} Roles Assigned</span>
              <div className="flex gap-3">
                <button onClick={() => setIsRoleModalOpen(false)} className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-white transition-colors">Cancel</button>
                <button 
                  onClick={handleAssignRoles}
                  disabled={saving}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  Update Access
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
