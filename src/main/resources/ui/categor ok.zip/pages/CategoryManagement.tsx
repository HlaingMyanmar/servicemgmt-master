
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { categoryService } from '../services/categoryapiservice';
import { CategoryDTO } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, Save, X, 
  Layers, ChevronRight, ChevronDown, FolderTree,
  RefreshCw, FilterX
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const CategoryManagement: React.FC = () => {
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [flatCategories, setFlatCategories] = useState<CategoryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [togglingId, setTogglingId] = useState<number | null>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryDTO | null>(null);
  const [formData, setFormData] = useState({ 
    name: '', 
    description: '', 
    active: true,
    parentId: null as number | null 
  });
  const [saving, setSaving] = useState(false);

  // Helper to flatten the tree and ensure parentId is explicitly set for every node
  const flatten = useCallback((items: CategoryDTO[], pid: number | null = null, result: CategoryDTO[] = []) => {
    items.forEach(item => {
      const currentParentId = (item.parentId !== undefined && item.parentId !== null) ? item.parentId : pid;
      const normalized = { ...item, parentId: currentParentId };
      result.push(normalized);
      if (item.children && item.children.length > 0) {
        flatten(item.children, item.id, result);
      }
    });
    return result;
  }, []);

  const fetchTreeData = useCallback(async () => {
    try {
      const data = await categoryService.getTree();
      setCategories(data);
      const flattened = flatten(data);
      setFlatCategories(flattened);
    } catch (error) {
      console.error("Failed to load categories", error);
    } finally {
      setLoading(false);
    }
  }, [flatten]);

  useEffect(() => {
    fetchTreeData();
  }, [fetchTreeData]);

  const handleWsMessage = useCallback(() => {
    setWsStatus('online');
    fetchTreeData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchTreeData]);

  useWebsocket('/topic/category', handleWsMessage);

  // Filtering Logic for Tree
  const filteredCategories = useMemo(() => {
    if (!searchTerm.trim()) return categories;
    
    const searchLower = searchTerm.toLowerCase();
    
    const filterNodes = (nodes: CategoryDTO[]): CategoryDTO[] => {
      return nodes.reduce((acc: CategoryDTO[], node) => {
        const selfMatches = node.name.toLowerCase().includes(searchLower) || 
                            (node.description?.toLowerCase().includes(searchLower));
        
        const filteredChildren = node.children ? filterNodes(node.children) : [];
        const hasMatchingChildren = filteredChildren.length > 0;
        
        if (selfMatches || hasMatchingChildren) {
          acc.push({
            ...node,
            children: filteredChildren
          });
        }
        return acc;
      }, []);
    };
    
    return filterNodes(categories);
  }, [categories, searchTerm]);

  // Auto-expand nodes that match search or have matching children
  useEffect(() => {
    if (searchTerm.trim()) {
      const newExpanded = new Set<number>();
      const searchLower = searchTerm.toLowerCase();
      
      const findAndExpand = (nodes: CategoryDTO[]) => {
        nodes.forEach(node => {
          const childMatches = node.children && node.children.some(c => 
            c.name.toLowerCase().includes(searchLower) || 
            (c.description?.toLowerCase().includes(searchLower)) ||
            (c.children && c.children.length > 0)
          );
          
          if (childMatches) {
            newExpanded.add(node.id);
            if (node.children) findAndExpand(node.children);
          }
        });
      };
      
      findAndExpand(categories);
      setExpandedIds(prev => new Set([...Array.from(prev), ...Array.from(newExpanded)]));
    }
  }, [searchTerm, categories]);

  const toggleExpand = (id: number) => {
    const next = new Set(expandedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedIds(next);
  };

  const handleOpenModal = (cat?: CategoryDTO) => {
    if (cat) {
      const normalizedNode = flatCategories.find(f => f.id === cat.id);
      const target = normalizedNode || cat;
      setEditingCategory(target);
      setFormData({ 
        name: target.name, 
        description: target.description || '', 
        active: target.active,
        parentId: target.parentId ?? null
      });
    } else {
      setEditingCategory(null);
      setFormData({ name: '', description: '', active: true, parentId: null });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: formData.name,
        description: formData.description,
        active: formData.active,
        parentId: formData.parentId
      };
      if (editingCategory) {
        await categoryService.update(editingCategory.id, payload);
      } else {
        await categoryService.create(payload);
      }
      setIsModalOpen(false);
      fetchTreeData();
      Swal.fire({ icon: 'success', title: 'Saved Successfully', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Operation failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (cat: CategoryDTO) => {
    setTogglingId(cat.id);
    try {
      const normalizedNode = flatCategories.find(f => f.id === cat.id);
      const currentParentId = normalizedNode?.parentId ?? null;
      await categoryService.update(cat.id, { 
        name: cat.name,
        active: !cat.active,
        parentId: currentParentId
      });
      fetchTreeData();
    } catch (error: any) {
      Swal.fire('Error', 'Status update failed', 'error');
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Remove Category?',
      text: "Sub-categories will lose their parent.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, Delete'
    });
    if (result.isConfirmed) {
      try {
        await categoryService.delete(id);
        fetchTreeData();
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  const CategoryRow: React.FC<{ cat: CategoryDTO; level: number }> = ({ cat, level }) => {
    const isExpanded = expandedIds.has(cat.id);
    const hasChildren = cat.children && cat.children.length > 0;
    
    // Highlight match in name if searching
    const highlightMatch = (text: string) => {
      if (!searchTerm.trim()) return text;
      const parts = text.split(new RegExp(`(${searchTerm})`, 'gi'));
      return parts.map((part, i) => 
        part.toLowerCase() === searchTerm.toLowerCase() 
          ? <span key={i} className="bg-yellow-100 text-yellow-800 rounded-sm px-0.5">{part}</span> 
          : part
      );
    };

    return (
      <>
        <tr className="group hover:bg-slate-50 transition-colors border-b border-slate-50">
          <td className="px-4 py-3">
            <div className="flex items-center" style={{ paddingLeft: `${level * 24}px` }}>
              <div className="flex items-center gap-1 min-w-[30px]">
                {hasChildren ? (
                  <button onClick={() => toggleExpand(cat.id)} className="p-1 hover:bg-slate-200 rounded text-slate-500 transition-colors">
                    {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  </button>
                ) : (
                  <div className="w-6" />
                )}
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all ${
                  cat.active ? 'bg-indigo-50 border-indigo-100 text-indigo-600' : 'bg-slate-50 border-slate-100 text-slate-400'
                }`}>
                  <Layers size={14} />
                </div>
              </div>
              <div className="ml-3 text-left">
                <p className={`text-[11px] font-bold ${cat.active ? 'text-slate-700' : 'text-slate-400'}`}>
                  {highlightMatch(cat.name)}
                </p>
                {cat.description && <p className="text-[9px] text-slate-400 mt-1 truncate max-w-xs">{highlightMatch(cat.description)}</p>}
              </div>
            </div>
          </td>
          <td className="px-4 py-3 text-center">
            <button 
              onClick={() => handleToggleStatus(cat)}
              disabled={togglingId === cat.id}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider border transition-all ${
                cat.active ? 'bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100' : 'bg-rose-50 text-rose-500 border-rose-100 hover:bg-rose-100'
              }`}
            >
              {togglingId === cat.id ? <RefreshCw size={10} className="animate-spin" /> : <div className={`w-1.5 h-1.5 rounded-full ${cat.active ? 'bg-emerald-500' : 'bg-rose-500'}`} />}
              {cat.active ? 'Active' : 'Inactive'}
            </button>
          </td>
          <td className="px-4 py-3">
            <div className="flex justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={() => handleOpenModal(cat)} className="p-1.5 text-slate-400 hover:text-indigo-600 bg-white border border-slate-200 rounded-lg shadow-sm hover:shadow-md transition-all"><Edit2 size={12} /></button>
              <button onClick={() => handleDelete(cat.id)} className="p-1.5 text-slate-400 hover:text-rose-600 bg-white border border-slate-200 rounded-lg shadow-sm hover:shadow-md transition-all"><Trash2 size={12} /></button>
            </div>
          </td>
        </tr>
        {isExpanded && hasChildren && cat.children?.map(child => (
          <CategoryRow key={child.id} cat={child} level={level + 1} />
        ))}
      </>
    );
  };

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-indigo-600" size={32} /></div>;

  return (
    <div className="space-y-4 animate-in fade-in duration-400 text-left">
      {/* Search and Action Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
            <FolderTree size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-slate-800 tracking-tight uppercase">Product Taxonomy</h2>
              <div className="flex items-center gap-1.5">
                <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-tighter border border-slate-200">
                  {flatCategories.length} Total
                </span>
                {searchTerm && (
                  <span className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-tighter border border-indigo-100">
                    {flatten(filteredCategories).length} Matches
                  </span>
                )}
                {wsStatus === 'online' && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ring-2 ring-emerald-100"></span>}
              </div>
            </div>
            <p className="text-slate-400 text-[10px] font-medium uppercase tracking-tighter mt-0.5">Manage nested hierarchy & stock grouping</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={14} />
            <input 
              type="text" 
              placeholder="Search category name or description..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl outline-none text-[11px] w-full md:w-64 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 shadow-sm transition-all"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 hover:bg-slate-100 rounded-full text-slate-400"
              >
                <X size={12} />
              </button>
            )}
          </div>
          <button 
            onClick={() => handleOpenModal()} 
            className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[11px] font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-2 hover:bg-indigo-700 active:scale-95 transition-all shrink-0"
          >
            <Plus size={16} /> New Node
          </button>
        </div>
      </div>

      {/* Main Content Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest w-2/3">Taxonomy Tree Structure</th>
                <th className="px-4 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Visiblity Status</th>
                <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Node Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredCategories.length > 0 ? (
                filteredCategories.map(cat => <CategoryRow key={cat.id} cat={cat} level={0} />)
              ) : (
                <tr>
                  <td colSpan={3} className="px-4 py-24 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 border-4 border-white shadow-inner">
                        {searchTerm ? <FilterX size={32} /> : <FolderTree size={32} />}
                      </div>
                      <div>
                        <p className="text-[12px] font-black text-slate-800 uppercase tracking-widest">
                          {searchTerm ? 'No results for your search' : 'Category Tree is Empty'}
                        </p>
                        <p className="text-[10px] text-slate-400 font-medium mt-1">
                          {searchTerm ? `Try adjusting your search term: "${searchTerm}"` : 'Get started by creating your first root category.'}
                        </p>
                      </div>
                      {searchTerm && (
                        <button 
                          onClick={() => setSearchTerm('')}
                          className="mt-2 text-[10px] font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100 transition-all"
                        >
                          Clear Search
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Create/Update */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-xs rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                  <Layers size={16} />
                </div>
                <div>
                  <h3 className="text-[11px] font-black text-slate-800 uppercase tracking-tight">
                    {editingCategory ? 'Modify Taxonomy Node' : 'Register New Node'}
                  </h3>
                  <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">Database entry</p>
                </div>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-1.5 hover:bg-slate-200 rounded-lg text-slate-400 transition-colors">
                <X size={16} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Category Label</label>
                <input 
                  type="text" required value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})} 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-medium outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all shadow-sm" 
                  placeholder="e.g., Computer Hardware"
                />
              </div>
              
              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Inheritance Link</label>
                <div className="relative">
                  <select 
                    value={formData.parentId === null ? "" : formData.parentId} 
                    onChange={(e) => {
                      const val = e.target.value;
                      setFormData({...formData, parentId: val === "" ? null : Number(val)});
                    }}
                    className="w-full pl-4 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-medium outline-none appearance-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all shadow-sm"
                  >
                    <option value="">-- No Parent (Root Level) --</option>
                    {flatCategories
                      .filter(c => !editingCategory || c.id !== editingCategory.id)
                      .map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))
                    }
                  </select>
                  <ChevronDown size={14} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Brief Description</label>
                <textarea 
                  rows={3} value={formData.description} 
                  onChange={(e) => setFormData({...formData, description: e.target.value})} 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-medium outline-none resize-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all shadow-sm"
                  placeholder="Details for reporting purposes..."
                />
              </div>

              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200/60">
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, active: !formData.active})}
                  className={`w-10 h-5.5 rounded-full transition-all relative ${formData.active ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-0.75 w-4 h-4 bg-white rounded-full transition-all shadow-md ${formData.active ? 'left-[22px]' : 'left-0.75'}`}></div>
                </button>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-700 uppercase tracking-tight leading-none">Status: {formData.active ? 'Visible' : 'Archived'}</span>
                  <span className="text-[8px] text-slate-400 font-bold uppercase mt-1">Visibility across ERP</span>
                </div>
              </div>

              <div className="flex gap-2.5 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="flex-1 py-2.5 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-500 hover:bg-slate-50 transition-all active:scale-95"
                >
                  Discard
                </button>
                <button 
                  type="submit" 
                  disabled={saving} 
                  className="flex-1 py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                  Save Node
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoryManagement;
