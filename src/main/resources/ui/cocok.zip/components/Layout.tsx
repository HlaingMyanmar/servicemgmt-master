
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LogOut,
  Menu,
  X,
  Bell,
  ShieldCheck,
  UserPlus,
  Key,
  ChevronLeft,
  LayoutDashboard,
  Package,
  Layers,
  Ruler,
  Box,
  Hash,
  Truck,
  Users,
  BookOpen
} from 'lucide-react';
import { User, AppRoute } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  const menuItems = [
    { name: 'Analytics', icon: <LayoutDashboard size={18} />, path: AppRoute.DASHBOARD, group: 'General' },
    { name: 'Products', icon: <Box size={18} />, path: AppRoute.PRODUCTS, group: 'Inventory' },
    { name: 'Serials', icon: <Hash size={18} />, path: AppRoute.PRODUCT_SERIALS, group: 'Inventory' },
    { name: 'Brands', icon: <Package size={18} />, path: AppRoute.BRANDS, group: 'Inventory' },
    { name: 'Categories', icon: <Layers size={18} />, path: AppRoute.CATEGORIES, group: 'Inventory' },
    { name: 'Units', icon: <Ruler size={18} />, path: AppRoute.UNITS, group: 'Inventory' },
    { name: 'Suppliers', icon: <Truck size={18} />, path: AppRoute.SUPPLIERS, group: 'Procurement' },
    { name: 'Customers', icon: <Users size={18} />, path: AppRoute.CUSTOMERS, group: 'CRM' },
    { name: 'Chart of Accounts', icon: <BookOpen size={18} />, path: AppRoute.COA, group: 'Accounting' },
    { name: 'User Access', icon: <UserPlus size={18} />, path: AppRoute.USERS, group: 'Security' },
    { name: 'Roles', icon: <ShieldCheck size={18} />, path: AppRoute.ROLES, group: 'Security' },
    { name: 'Permissions', icon: <Key size={18} />, path: AppRoute.PERMISSIONS, group: 'Security' },
  ];

  const currentPathName = menuItems.find(i => i.path === location.pathname)?.name || 'Management System';

  return (
    <div className="min-h-screen flex bg-slate-50 overflow-hidden text-slate-800">
      <aside 
        className={`bg-slate-900 text-white fixed lg:static inset-y-0 left-0 z-50 transform 
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
          ${isCollapsed ? 'lg:w-16' : 'lg:w-56'} 
          transition-all duration-300 ease-in-out flex flex-col shadow-xl`}
      >
        <div className={`p-4 border-b border-slate-800 flex items-center min-h-[48px] ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
          <div className="flex items-center gap-2 overflow-hidden text-left">
            <div className="w-6 h-6 bg-indigo-500 rounded flex items-center justify-center font-bold text-xs text-white shrink-0">S</div>
            {!isCollapsed && <span className="text-lg font-bold tracking-tight whitespace-nowrap">SSPD ERP</span>}
          </div>
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="hidden lg:flex p-1 text-slate-400 hover:text-white rounded"><ChevronLeft className={isCollapsed ? 'rotate-180' : ''} size={16} /></button>
          <button className="lg:hidden text-slate-400" onClick={() => setSidebarOpen(false)}><X size={18} /></button>
        </div>

        <nav className="flex-1 px-2 py-4 overflow-y-auto space-y-4 custom-scrollbar text-left">
          {['General', 'Inventory', 'Procurement', 'CRM', 'Accounting', 'Security'].map(group => {
            const items = menuItems.filter(i => i.group === group);
            if (items.length === 0) return null;
            return (
              <div key={group} className="space-y-1">
                {!isCollapsed && <p className="px-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">{group}</p>}
                {items.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                      location.pathname === item.path ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    } ${isCollapsed ? 'justify-center px-0' : ''}`}
                    title={isCollapsed ? item.name : ''}
                  >
                    {item.icon}
                    {!isCollapsed && <span className="text-xs font-medium">{item.name}</span>}
                  </Link>
                ))}
              </div>
            );
          })}
        </nav>

        <div className="p-2 border-t border-slate-800">
          <button onClick={onLogout} className={`flex items-center gap-3 px-3 py-2 w-full rounded-lg text-rose-400 hover:bg-rose-500/10 transition-all ${isCollapsed ? 'justify-center px-0' : ''}`}>
            <LogOut size={18} />
            {!isCollapsed && <span className="text-xs font-medium">Sign Out</span>}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-12 bg-white border-b border-slate-200 flex items-center justify-between px-4 sticky top-0 z-40">
          <div className="flex items-center gap-3">
            <button className="p-1.5 lg:hidden" onClick={() => setSidebarOpen(true)}><Menu size={18} /></button>
            <h1 className="text-sm font-bold text-slate-800">{currentPathName}</h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg relative">
              <Bell size={18} />
              <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-rose-500 rounded-full border border-white"></span>
            </button>
            <div className="flex items-center gap-2 bg-slate-50 p-1 pr-2 rounded-lg border border-slate-100">
              <div className="w-6 h-6 rounded bg-indigo-600 text-white flex items-center justify-center text-[10px] font-bold">{user.username.charAt(0)}</div>
              <div className="hidden sm:block text-left">
                <p className="text-[10px] font-bold text-slate-800 leading-none">{user.username}</p>
                <p className="text-[8px] text-slate-400 uppercase font-bold mt-0.5">{user.roles[0]?.replace('ROLE_', '') || 'User'}</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 overflow-y-auto bg-slate-50/50 custom-scrollbar">
          {children}
        </main>
      </div>
      {isSidebarOpen && <div className="fixed inset-0 bg-slate-900/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}
    </div>
  );
};

export default Layout;
