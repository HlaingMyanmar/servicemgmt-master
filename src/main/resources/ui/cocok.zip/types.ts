
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

export interface AuthResponse {
  accessToken: string;
  username: string;
  roles: string[];
  permissions: string[];
}

export interface User {
  username: string;
  roles: string[];
  permissions: string[];
}

export interface PermissionDTO {
  id: number;
  name: string;
  description?: string;
}

export interface RoleDTO {
  id: number;
  name: string;
  description?: string;
  permissions: PermissionDTO[];
}

export interface UserDTO {
  id: number;
  username: string;
  email: string;
  authProvider: string;
  isActive: boolean;
  roles: string[];
}

export interface BrandDTO {
  id: number;
  name: string;
  isActive: boolean;
}

export interface UnitDTO {
  id: number;
  unitName: string;
  description?: string;
}

export interface CategoryDTO {
  id: number;
  name: string;
  description?: string;
  active: boolean;
  parentId: number | null;
  parentName?: string;
  children?: CategoryDTO[];
}

export enum ProductType {
  NEW = 'New',
  SECOND = 'Second'
}

export interface ProductDTO {
  id: number;
  productCode: string;
  name: string;
  currentStock: number;
  productType: ProductType;
  sellingPrice: number;
  remark?: string;
  categoryId?: number;
  categoryName?: string;
  brandId?: number;
  brandName?: string;
  unitId?: number;
  unitName?: string;
}

export enum SerialStatus {
  AVAILABLE = 'Available',
  SOLD = 'Sold',
  USED_IN_SERVICE = 'Used_In_Service',
  DAMAGED = 'Damaged'
}

export interface ProductSerialDTO {
  id: number;
  serialNumber: string;
  status: SerialStatus;
  productId: number;
  productName?: string;
}

export interface SupplierDTO {
  id: number;
  code: string;
  name: string;
  phone?: string;
  address?: string;
  openingBalance: number;
  currentBalance: number;
}

export interface CustomerGroupDTO {
  id: number;
  name: string;
  description?: string;
}

export interface CustomerDTO {
  id: number;
  customerCode: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  customerGroupId?: number;
  customerGroupName?: string;
  openingBalance: number;
  currentBalance: number;
}

export enum AccountType {
  Asset = 'Asset',
  Liability = 'Liability',
  Equity = 'Equity',
  Income = 'Income',
  Expense = 'Expense'
}

export interface ChartOfAccountDTO {
  id: number;
  accountName: string;
  accountType: AccountType;
  code: string;
  parentId: number | null;
  parentName?: string;
  children?: ChartOfAccountDTO[];
}

export interface DashboardStats {
  totalSales: number;
  totalPurchases: number;
  totalServices: number;
  totalCustomers: number;
  recentSales: SaleSummary[];
}

export interface SaleSummary {
  id: number;
  saleCode: string;
  customerName: string;
  amount: number;
  date: string;
  status: 'Paid' | 'Partial' | 'Pending';
}

export enum AppRoute {
  LOGIN = '/login',
  DASHBOARD = '/',
  USERS = '/rbac/users',
  ROLES = '/rbac/roles',
  PERMISSIONS = '/rbac/permissions',
  PRODUCTS = '/inventory/products',
  PRODUCT_SERIALS = '/inventory/serials',
  BRANDS = '/inventory/brands',
  CATEGORIES = '/inventory/categories',
  UNITS = '/inventory/units',
  SUPPLIERS = '/procurement/suppliers',
  CUSTOMERS = '/crm/customers',
  COA = '/accounting/coa'
}
