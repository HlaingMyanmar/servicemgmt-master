
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { productService } from '../services/productapiservice';
import { brandService } from '../services/brandapiservice';
import { categoryService } from '../services/categoryapiservice';
import { unitService } from '../services/unitapiservice';
import { ProductDTO, BrandDTO, CategoryDTO, UnitDTO, ProductType } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, X, 
  Box, ChevronLeft, ChevronRight, ChevronDown,
  Tag, Package, Ruler, Layers, DollarSign,
  Save, StickyNote
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

interface CategoryOption {
  id: number;
  displayName: string;
}

const ProductManagement: React.FC = () => {
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [brands, setBrands] = useState<BrandDTO[]>([]);
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [units, setUnits] = useState<UnitDTO[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductDTO | null>(null);
  const [formData, setFormData] = useState<Partial<ProductDTO>>({
    name: '',
    currentStock: 0,
    productType: ProductType.NEW,
    sellingPrice: 0,
    remark: '',
    categoryId: undefined,
    brandId: undefined,
    unitId: undefined
  });
  const [saving, setSaving] = useState(false);

  const getCategoryOptions = useCallback((nodes: CategoryDTO[], level = 0): CategoryOption[] => {
    return nodes.reduce((acc: CategoryOption[], node) => {
      const indentation = "\u00A0\u00A0".repeat(level * 2);
      const prefix = level > 0 ? "↳ " : "";
      acc.push({ id: node.id, displayName: `${indentation}${prefix}${node.name}` });
      if (node.children && node.children.length > 0) {
        acc.push(...getCategoryOptions(node.children, level + 1));
      }
      return acc;
    }, []);
  }, []);

  const fetchData = useCallback(async () => {
    try {
      const [pData, bData, cTreeData, uData] = await Promise.all([
        productService.getAll(),
        brandService.getAll(),
        categoryService.getTree(),
        unitService.getAll()
      ]);
      setProducts(pData);
      setBrands(bData.filter(b => b.isActive));
      setCategories(cTreeData);
      setUnits(uData);
    } catch (error) {
      console.error("Failed to load inventory data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleWsMessage = useCallback(() => {
    setWsStatus('online');
    fetchData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchData]);

  useWebsocket('/topic/product', handleWsMessage);

  const flatCategoryOptions = useMemo(() => getCategoryOptions(categories), [categories, getCategoryOptions]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => 
      p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [products, searchTerm]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedProducts = filteredProducts.slice(startIndex, startIndex + itemsPerPage);

  const handleOpenModal = (product?: ProductDTO) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        currentStock: product.currentStock,
        productType: product.productType,
        sellingPrice: product.sellingPrice,
        remark: product.remark || '',
        categoryId: product.categoryId,
        brandId: product.brandId,
        unitId: product.unitId
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: '',
        currentStock: 0,
        productType: ProductType.NEW,
        sellingPrice: 0,
        remark: '',
        categoryId: undefined,
        brandId: undefined,
        unitId: undefined
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { 
        ...formData, 
        productCode: editingProduct?.productCode || `P-${Date.now().toString().slice(-6)}` 
      };
      
      if (editingProduct) {
        await productService.update(editingProduct.id, payload);
      } else {
        await productService.create(payload);
      }
      setIsModalOpen(false);
      fetchData();
      Swal.fire({ icon: 'success', title: 'Product Saved', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Validation failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Delete Product?',
      text: "This action cannot be undone.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#94a3b8',
      confirmButtonText: 'Yes, delete it'
    });

    if (result.isConfirmed) {
      try {
        await productService.delete(id);
        fetchData();
        Swal.fire({ icon: 'success', title: 'Deleted', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-600" size={32} />
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-400 h-full flex flex-col overflow-hidden text-left">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-100">
            <Box size={24} />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-800 tracking-tight uppercase">Inventory Master</h2>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5">Product & Stock Management</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={16} />
            <input 
              type="text" placeholder="Filter by product name..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-11 pr-3 py-2.5 bg-white border border-slate-200 rounded-2xl outline-none text-[11px] font-bold w-full md:w-64 focus:border-indigo-500 transition-all shadow-sm"
            />
          </div>
          <button 
            onClick={() => handleOpenModal()} 
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase shadow-xl shadow-indigo-100 active:scale-95 transition-all flex items-center gap-1.5"
          >
            <Plus size={18} /> Add Product
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[1.5rem] shadow-xl shadow-slate-200/50 border border-slate-200 flex flex-col flex-1 overflow-hidden">
        <div className="flex-1 overflow-auto custom-scrollbar relative">
          <table className="w-full text-left border-collapse min-w-[1200px]">
            <thead className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-sm border-b border-slate-200 shadow-sm">
              <tr>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Product Name</th>
                <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Classification</th>
                <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Stock</th>
                <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Selling Price</th>
                <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Condition</th>
                <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Remark</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedProducts.length > 0 ? paginatedProducts.map((product) => (
                <tr key={product.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                        <Package size={18} />
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-800 tracking-tight">{product.name}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest italic">Code: {product.productCode}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        <Tag size={10} className="text-slate-400" />
                        <span className="text-[10px] font-bold text-slate-600">{product.brandName || 'Unbranded'}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Layers size={10} className="text-slate-400" />
                        <span className="text-[10px] font-bold text-slate-500">{product.categoryName || 'General'}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-center">
                    <div className="flex flex-col items-center">
                      <span className={`text-xs font-black ${product.currentStock <= 5 ? 'text-rose-600' : 'text-slate-800'}`}>
                        {product.currentStock}
                      </span>
                      <span className="text-[9px] text-slate-400 font-bold uppercase">{product.unitName || 'Units'}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <span className="text-xs font-black text-slate-800">
                      Ks {product.sellingPrice.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                      product.productType === ProductType.NEW ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                    }`}>
                      {product.productType}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-1.5 max-w-[150px]">
                      {product.remark ? (
                        <>
                          <StickyNote size={10} className="text-slate-300 shrink-0" />
                          <p className="text-[10px] text-slate-500 truncate font-medium italic" title={product.remark}>{product.remark}</p>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-300 font-bold uppercase">None</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleOpenModal(product)} className="p-2 text-slate-400 hover:text-indigo-600 bg-white border border-slate-200 rounded-xl shadow-sm transition-all">
                        <Edit2 size={12} />
                      </button>
                      <button onClick={() => handleDelete(product.id)} className="p-2 text-slate-400 hover:text-rose-600 bg-white border border-slate-200 rounded-xl shadow-sm transition-all">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr><td colSpan={7} className="px-6 py-24 text-center text-slate-400 text-xs font-bold tracking-widest">NO PRODUCTS FOUND</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {filteredProducts.length > 0 && (
          <div className="sticky bottom-0 z-30 px-8 py-5 bg-white border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
            <div className="w-full md:w-auto text-center md:text-left order-2 md:order-1">
              <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">
                Showing <span className="text-indigo-600">{startIndex + 1}</span> to <span className="text-indigo-600">{Math.min(startIndex + itemsPerPage, filteredProducts.length)}</span> of <span className="text-slate-800">{filteredProducts.length}</span> items
              </span>
            </div>

            <div className="w-full md:w-auto flex flex-col sm:flex-row items-center justify-center gap-4 order-1 md:order-2">
              <div className="relative group">
                <select 
                  value={itemsPerPage} onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                  className="appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-1.5 pr-10 text-[10px] font-black text-slate-600 outline-none focus:bg-white focus:border-indigo-500 cursor-pointer transition-all"
                >
                  <option value={10}>10 per page</option>
                  <option value={25}>25 per page</option>
                  <option value={50}>50 per page</option>
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none group-hover:text-indigo-500 transition-colors" />
              </div>

              <div className="flex items-center gap-1.5">
                <button 
                  disabled={currentPage === 1} 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} 
                  className="p-2.5 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all active:scale-90"
                >
                  <ChevronLeft size={16} />
                </button>
                <div className="flex gap-1">
                  {[...Array(totalPages)].map((_, i) => {
                    const pageNum = i + 1;
                    if (totalPages > 5 && Math.abs(pageNum - currentPage) > 1 && pageNum !== 1 && pageNum !== totalPages) return null;
                    return (
                      <button 
                        key={i} 
                        onClick={() => setCurrentPage(pageNum)} 
                        className={`min-w-[40px] h-10 rounded-xl text-[11px] font-black transition-all ${
                          currentPage === pageNum ? 'bg-indigo-600 text-white shadow-lg border-indigo-600 scale-105' : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50'
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                </div>
                <button 
                  disabled={currentPage === totalPages} 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))} 
                  className="p-2.5 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all active:scale-90"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-[2rem] shadow-2xl border border-slate-200 animate-in zoom-in-95 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-[12px] font-black text-slate-800 uppercase tracking-tight">{editingProduct ? 'Update' : 'New'} Product</h3>
                <p className="text-[9px] text-slate-400 font-bold uppercase mt-0.5 tracking-widest">Inventory Management</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors"><X size={20} className="text-slate-400" /></button>
            </div>
            
            <form onSubmit={handleSave} className="p-8 space-y-6 text-left max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Product Name</label>
                  <div className="relative group">
                    <Package className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <input 
                      type="text" required value={formData.name} 
                      onChange={(e) => setFormData({...formData, name: e.target.value})} 
                      className="w-full pl-10 pr-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all" 
                      placeholder="e.g. MacBook Pro M3"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Product Condition</label>
                  <div className="flex gap-2 p-1 bg-slate-50 rounded-2xl border border-slate-200">
                    <button 
                      type="button" 
                      onClick={() => setFormData({...formData, productType: ProductType.NEW})}
                      className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${formData.productType === ProductType.NEW ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                      New
                    </button>
                    <button 
                      type="button" 
                      onClick={() => setFormData({...formData, productType: ProductType.SECOND})}
                      className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${formData.productType === ProductType.SECOND ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                      Second
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Selling Price (MMK)</label>
                  <div className="relative group">
                    <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <input 
                      type="number" required min="0" value={formData.sellingPrice} 
                      onChange={(e) => setFormData({...formData, sellingPrice: Number(e.target.value)})} 
                      className="w-full pl-10 pr-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all" 
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Stock Quantity</label>
                  <div className="relative group">
                    <Box className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <input 
                      type="number" required min="0" value={formData.currentStock} 
                      onChange={(e) => setFormData({...formData, currentStock: Number(e.target.value)})} 
                      className="w-full pl-10 pr-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all" 
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Category & Sub-Category</label>
                  <div className="relative group">
                    <Layers className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <select 
                      required value={formData.categoryId || ''} 
                      onChange={(e) => setFormData({...formData, categoryId: Number(e.target.value)})}
                      className="w-full pl-10 pr-8 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all appearance-none"
                    >
                      <option value="">Select Category Tree</option>
                      {flatCategoryOptions.map(opt => (
                        <option key={opt.id} value={opt.id}>{opt.displayName}</option>
                      ))}
                    </select>
                    <ChevronDown size={14} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Brand</label>
                  <div className="relative group">
                    <Tag className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <select 
                      required value={formData.brandId || ''} 
                      onChange={(e) => setFormData({...formData, brandId: Number(e.target.value)})}
                      className="w-full pl-10 pr-8 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all appearance-none"
                    >
                      <option value="">Select Brand</option>
                      {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                    <ChevronDown size={14} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Unit</label>
                  <div className="relative group">
                    <Ruler className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={14} />
                    <select 
                      required value={formData.unitId || ''} 
                      onChange={(e) => setFormData({...formData, unitId: Number(e.target.value)})}
                      className="w-full pl-10 pr-8 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all appearance-none"
                    >
                      <option value="">Select Unit</option>
                      {units.map(u => <option key={u.id} value={u.id}>{u.unitName}</option>)}
                    </select>
                    <ChevronDown size={14} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Internal Remarks</label>
                <textarea 
                  rows={3} 
                  value={formData.remark} 
                  onChange={(e) => setFormData({...formData, remark: e.target.value})} 
                  className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all resize-none" 
                  placeholder="Additional product info..."
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="flex-1 py-4 border border-slate-200 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-500 hover:bg-slate-50 transition-all"
                >
                  Discard
                </button>
                <button 
                  type="submit" 
                  disabled={saving} 
                  className="flex-[2] py-4 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                  Confirm & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductManagement;
