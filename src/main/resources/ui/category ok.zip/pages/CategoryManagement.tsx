
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { categoryService } from '../services/categoryapiservice';
import { CategoryDTO } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, Save, X, 
  Layers, ChevronRight, ChevronDown, FolderTree,
  RefreshCw, FilterX, PlusCircle, Link2, Filter,
  Check, Folder, Tag, FileText
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

const CategoryManagement: React.FC = () => {
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [flatCategories, setFlatCategories] = useState<CategoryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [wsStatus, setWsStatus] = useState<'online' | 'offline'>('offline');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [filterActive, setFilterActive] = useState(true);
  const [filterInactive, setFilterInactive] = useState(false);

  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [togglingId, setTogglingId] = useState<number | null>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryDTO | null>(null);
  
  const [formData, setFormData] = useState({ 
    name: '', 
    description: '', 
    active: true,
    parentId: null as number | null 
  });
  const [saving, setSaving] = useState(false);

  const flatten = useCallback((items: CategoryDTO[], pid: number | null = null, result: CategoryDTO[] = []) => {
    items.forEach(item => {
      const currentParentId = (item.parentId !== undefined && item.parentId !== null) ? item.parentId : pid;
      const normalized = { ...item, parentId: currentParentId };
      result.push(normalized);
      if (item.children && item.children.length > 0) {
        flatten(item.children, item.id, result);
      }
    });
    return result;
  }, []);

  const fetchTreeData = useCallback(async () => {
    try {
      const data = await categoryService.getTree();
      setCategories(data);
      const flattened = flatten(data);
      setFlatCategories(flattened);
    } catch (error) {
      console.error("Failed to load categories", error);
    } finally {
      setLoading(false);
    }
  }, [flatten]);

  useEffect(() => {
    fetchTreeData();
  }, [fetchTreeData]);

  const handleWsMessage = useCallback(() => {
    setWsStatus('online');
    fetchTreeData();
    const timer = setTimeout(() => setWsStatus('offline'), 5000);
    return () => clearTimeout(timer);
  }, [fetchTreeData]);

  useWebsocket('/topic/category', handleWsMessage);

  const filteredCategories = useMemo(() => {
    const searchLower = searchTerm.toLowerCase().trim();
    
    const filterNodes = (nodes: CategoryDTO[]): CategoryDTO[] => {
      return nodes.reduce((acc: CategoryDTO[], node) => {
        const matchesStatus = (node.active && filterActive) || (!node.active && filterInactive);
        const matchesSearch = !searchLower || 
                             node.name.toLowerCase().includes(searchLower) || 
                             (node.description?.toLowerCase().includes(searchLower));
        
        const filteredChildren = node.children ? filterNodes(node.children) : [];
        
        if ((matchesStatus && matchesSearch) || filteredChildren.length > 0) {
          acc.push({ ...node, children: filteredChildren });
        }
        return acc;
      }, []);
    };
    
    return filterNodes(categories);
  }, [categories, searchTerm, filterActive, filterInactive]);

  useEffect(() => {
    if (searchTerm.trim()) {
      const newExpanded = new Set<number>();
      const searchLower = searchTerm.toLowerCase();
      const findAndExpand = (nodes: CategoryDTO[]) => {
        nodes.forEach(node => {
          const childMatches = node.children && node.children.some(c => 
            c.name.toLowerCase().includes(searchLower) || 
            (c.description?.toLowerCase().includes(searchLower)) ||
            (c.children && c.children.length > 0)
          );
          if (childMatches) {
            newExpanded.add(node.id);
            if (node.children) findAndExpand(node.children);
          }
        });
      };
      findAndExpand(categories);
      setExpandedIds(prev => new Set([...Array.from(prev), ...Array.from(newExpanded)]));
    }
  }, [searchTerm, categories]);

  const toggleExpand = (id: number) => {
    const next = new Set(expandedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedIds(next);
  };

  const handleOpenModal = (cat?: CategoryDTO, isAddingChild: boolean = false) => {
    if (cat && !isAddingChild) {
      const normalizedNode = flatCategories.find(f => f.id === cat.id);
      const target = normalizedNode || cat;
      setEditingCategory(target);
      setFormData({ 
        name: target.name, 
        description: target.description || '', 
        active: target.active,
        parentId: target.parentId ?? null
      });
    } else if (cat && isAddingChild) {
      setEditingCategory(null);
      setFormData({ 
        name: '', 
        description: '', 
        active: true, 
        parentId: cat.id 
      });
    } else {
      setEditingCategory(null);
      setFormData({ name: '', description: '', active: true, parentId: null });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    
    setSaving(true);
    try {
      const payload = {
        name: formData.name.trim(),
        description: formData.description.trim(),
        active: formData.active,
        parentId: formData.parentId 
      };
      
      if (editingCategory) {
        await categoryService.update(editingCategory.id, payload);
      } else {
        await categoryService.create(payload);
      }
      
      setIsModalOpen(false);
      fetchTreeData();
      Swal.fire({ icon: 'success', title: 'Success', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Operation failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (cat: CategoryDTO) => {
    setTogglingId(cat.id);
    try {
      const normalizedNode = flatCategories.find(f => f.id === cat.id);
      const currentParentId = normalizedNode?.parentId ?? null;
      await categoryService.update(cat.id, { 
        name: cat.name,
        active: !cat.active,
        parentId: currentParentId
      });
      fetchTreeData();
    } catch (error: any) {
      Swal.fire('Error', 'Status update failed', 'error');
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Delete Category?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Delete'
    });
    if (result.isConfirmed) {
      try {
        await categoryService.delete(id);
        fetchTreeData();
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  const CategoryRow: React.FC<{ cat: CategoryDTO; level: number; isLast: boolean; parentPaths: boolean[] }> = ({ cat, level, isLast, parentPaths }) => {
    const isExpanded = expandedIds.has(cat.id);
    const hasChildren = cat.children && cat.children.length > 0;
    const directChildCount = cat.children?.length || 0;
    
    const highlightMatch = (text: string) => {
      if (!searchTerm.trim()) return text;
      const parts = text.split(new RegExp(`(${searchTerm})`, 'gi'));
      return parts.map((part, i) => 
        part.toLowerCase() === searchTerm.toLowerCase() 
          ? <span key={i} className="bg-yellow-100 text-yellow-800 rounded-sm px-0.5 font-bold">{part}</span> 
          : part
      );
    };

    return (
      <>
        <tr className="group hover:bg-indigo-50/30 transition-all border-b border-slate-50 cursor-pointer" onClick={() => handleOpenModal(cat)}>
          <td className="px-4 py-1.5 relative">
            <div className="flex items-center h-full">
              {/* Hierarchy Connectors */}
              <div className="flex h-10">
                {parentPaths.map((hasNeighbor, i) => (
                  <div key={i} className="relative w-8 flex-shrink-0">
                    {hasNeighbor && <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-slate-200" />}
                  </div>
                ))}
                
                <div className="relative w-8 flex-shrink-0">
                  {/* Vertical line from top to center */}
                  <div className={`absolute left-1/2 top-0 ${isLast ? 'h-1/2' : 'h-full'} w-[1px] bg-slate-200`} />
                  {/* Horizontal line to the right */}
                  <div className="absolute left-1/2 top-1/2 w-4 h-[1px] bg-slate-200" />
                </div>
              </div>

              {/* Node Icon & Content */}
              <div className="flex items-center gap-1.5 ml-1">
                <div className="flex items-center justify-center w-6 h-6" onClick={(e) => e.stopPropagation()}>
                  {hasChildren ? (
                    <button 
                      onClick={() => toggleExpand(cat.id)} 
                      className={`p-1 hover:bg-indigo-100 rounded text-slate-500 transition-all transform ${isExpanded ? 'rotate-0' : '-rotate-0'}`}
                    >
                      {isExpanded ? <ChevronDown size={14} className="text-indigo-600" /> : <ChevronRight size={14} />}
                    </button>
                  ) : (
                    <div className="w-6" />
                  )}
                </div>

                <div className={`w-8 h-8 rounded-xl flex items-center justify-center border transition-all shadow-sm ${
                  cat.active 
                    ? 'bg-white border-indigo-100 text-indigo-600' 
                    : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}>
                  {hasChildren ? <Folder size={14} fill={cat.active ? "currentColor" : "none"} fillOpacity={0.1} /> : <Tag size={14} />}
                </div>

                <div className="ml-2 py-2">
                  <div className="flex items-center gap-2">
                    <p className={`text-[11px] font-black tracking-tight ${cat.active ? 'text-slate-700' : 'text-slate-400'}`}>
                      {highlightMatch(cat.name)}
                    </p>
                    {directChildCount > 0 && (
                      <span className="bg-indigo-50 text-indigo-500 text-[8px] font-black px-1.5 py-0.5 rounded-md border border-indigo-100">
                        {directChildCount} Items
                      </span>
                    )}
                  </div>
                  {cat.description && (
                    <p className="text-[9px] text-slate-400 mt-0.5 truncate max-w-[200px] font-medium italic">
                      {highlightMatch(cat.description)}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </td>
          <td className="px-4 py-3 text-center align-middle" onClick={(e) => e.stopPropagation()}>
            <button 
              onClick={() => handleToggleStatus(cat)}
              disabled={togglingId === cat.id}
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border transition-all ${
                cat.active ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
              }`}
            >
              {togglingId === cat.id ? <RefreshCw size={10} className="animate-spin" /> : <div className={`w-1.5 h-1.5 rounded-full ${cat.active ? 'bg-emerald-500' : 'bg-slate-400'}`} />}
              {cat.active ? 'Active' : 'Inactive'}
            </button>
          </td>
          <td className="px-4 py-3 align-middle" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={() => handleOpenModal(cat)} className="p-2 text-slate-400 hover:text-indigo-600 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5"><Edit2 size={12} /></button>
              <button onClick={() => handleDelete(cat.id)} className="p-2 text-slate-400 hover:text-rose-600 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5"><Trash2 size={12} /></button>
            </div>
          </td>
        </tr>
        {isExpanded && hasChildren && cat.children?.map((child, index) => (
          <CategoryRow 
            key={child.id} 
            cat={child} 
            level={level + 1} 
            isLast={index === (cat.children?.length || 0) - 1}
            parentPaths={[...parentPaths, !isLast]}
          />
        ))}
      </>
    );
  };

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-indigo-600" size={32} /></div>;

  return (
    <div className="space-y-4 animate-in fade-in duration-400 text-left">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 transform -rotate-3 hover:rotate-0 transition-transform">
            <FolderTree size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-slate-800 tracking-tight uppercase">Inventory Taxonomy</h2>
              <div className="flex items-center gap-1.5">
                <span className="bg-indigo-50 text-indigo-600 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter border border-indigo-100">
                  {flatCategories.length} Nodes
                </span>
                {wsStatus === 'online' && <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse ring-4 ring-emerald-50"></span>}
              </div>
            </div>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5">Logical Product Classification Tree</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filters Group */}
          <div className="flex items-center bg-white border border-slate-200 rounded-2xl p-1 gap-1 shadow-sm">
            <button 
              onClick={() => { setFilterActive(true); setFilterInactive(true); }}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                filterActive && filterInactive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-400 hover:bg-slate-50'
              }`}
            >
              All
            </button>
            <div className="w-px h-5 bg-slate-100 mx-1"></div>
            
            <label className="flex items-center gap-2.5 px-3 py-2 hover:bg-slate-50 rounded-xl cursor-pointer transition-all group">
              <input 
                type="checkbox" 
                className="hidden" 
                checked={filterActive} 
                onChange={() => setFilterActive(!filterActive)} 
              />
              <div className={`w-4.5 h-4.5 rounded-lg border flex items-center justify-center transition-all ${
                filterActive ? 'bg-emerald-500 border-emerald-500 text-white shadow-md' : 'border-slate-300 bg-white group-hover:border-slate-400'
              }`}>
                {filterActive && <Check size={12} strokeWidth={4} />}
              </div>
              <span className={`text-[10px] font-black uppercase tracking-tighter ${filterActive ? 'text-slate-700' : 'text-slate-400'}`}>Active</span>
            </label>

            <label className="flex items-center gap-2.5 px-3 py-2 hover:bg-slate-50 rounded-xl cursor-pointer transition-all group">
              <input 
                type="checkbox" 
                className="hidden" 
                checked={filterInactive} 
                onChange={() => setFilterInactive(!filterInactive)} 
              />
              <div className={`w-4.5 h-4.5 rounded-lg border flex items-center justify-center transition-all ${
                filterInactive ? 'bg-rose-500 border-rose-500 text-white shadow-md' : 'border-slate-300 bg-white group-hover:border-slate-400'
              }`}>
                {filterInactive && <Check size={12} strokeWidth={4} />}
              </div>
              <span className={`text-[10px] font-black uppercase tracking-tighter ${filterInactive ? 'text-slate-700' : 'text-slate-400'}`}>Inactive</span>
            </label>
          </div>

          <div className="relative group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="Search nodes..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-11 pr-10 py-2.5 bg-white border border-slate-200 rounded-2xl outline-none text-[11px] font-bold w-full md:w-64 focus:border-indigo-500 transition-all shadow-sm focus:ring-4 focus:ring-indigo-500/5"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={14} /></button>
            )}
          </div>
          
          <button 
            onClick={() => handleOpenModal()} 
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 flex items-center gap-2 hover:bg-indigo-700 hover:-translate-y-0.5 active:scale-95 transition-all shrink-0"
          >
            <Plus size={18} strokeWidth={3} /> New Entry
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/40 border border-slate-200/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/80 backdrop-blur-md border-b border-slate-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Classification & Depth</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Visibility</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredCategories.length > 0 ? (
                filteredCategories.map((cat, index) => (
                  <CategoryRow 
                    key={cat.id} 
                    cat={cat} 
                    level={0} 
                    isLast={index === filteredCategories.length - 1}
                    parentPaths={[]}
                  />
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="px-4 py-32 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-200 border-8 border-white shadow-inner">
                        <FilterX size={40} />
                      </div>
                      <div className="space-y-1">
                        <p className="text-[12px] text-slate-800 font-black uppercase tracking-widest">Isolation Detected</p>
                        <p className="text-[10px] text-slate-400 font-medium">No categories match your active criteria</p>
                      </div>
                      <button 
                        onClick={() => { setSearchTerm(''); setFilterActive(true); setFilterInactive(false); }}
                        className="mt-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 transition-colors shadow-lg shadow-slate-200"
                      >
                        Reset System Filters
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-xs rounded-[2rem] shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                  <Layers size={20} />
                </div>
                <div>
                  <h3 className="text-[12px] font-black text-slate-800 uppercase tracking-tight">
                    {editingCategory ? 'Modify Node' : (formData.parentId ? 'Add Sub-node' : 'Root Entry')}
                  </h3>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Metadata Registry</p>
                </div>
              </div>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-5">
              {editingCategory && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 flex items-center gap-2">
                    <Link2 size={12} className="text-indigo-500" /> Hierarchy Parent
                  </label>
                  <div className="relative">
                    <select 
                      value={formData.parentId === null ? "" : formData.parentId} 
                      onChange={(e) => {
                        const val = e.target.value;
                        setFormData({...formData, parentId: val === "" ? null : Number(val)});
                      }}
                      className="w-full pl-4 pr-10 py-3 bg-indigo-50 border border-indigo-100 rounded-2xl text-[11px] font-black text-indigo-700 outline-none appearance-none cursor-pointer focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    >
                      <option value="">-- Main Root (Top Level) --</option>
                      {flatCategories
                        .filter(c => c.id !== editingCategory.id)
                        .map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))
                      }
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-400 pointer-events-none" />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Label Name</label>
                <input 
                  type="text" required value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})} 
                  className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-bold outline-none focus:border-indigo-500 transition-all shadow-sm focus:ring-4 focus:ring-indigo-500/5" 
                  placeholder="e.g. Hardware Components"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Operational Notes</label>
                <textarea 
                  rows={2} value={formData.description} 
                  onChange={(e) => setFormData({...formData, description: e.target.value})} 
                  className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-medium outline-none resize-none focus:border-indigo-500 transition-all shadow-sm focus:ring-4 focus:ring-indigo-500/5"
                  placeholder="Classification details..."
                />
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-[1.5rem] border border-slate-200/60 transition-all hover:bg-white hover:border-indigo-200">
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, active: !formData.active})}
                  className={`w-10 h-6 rounded-full transition-all relative shadow-inner ${formData.active ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all shadow-md ${formData.active ? 'left-5' : 'left-1'}`}></div>
                </button>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-700 uppercase tracking-tight">Visibility Status</span>
                  <span className={`text-[8px] font-bold uppercase ${formData.active ? 'text-emerald-500' : 'text-slate-400'}`}>
                    {formData.active ? 'Public / Visible' : 'Hidden / Internal'}
                  </span>
                </div>
              </div>

              <div className="flex gap-3 pt-3">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="flex-1 py-3 border border-slate-200 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-500 hover:bg-slate-50 transition-all active:scale-95"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={saving} 
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-2 hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                  Save Node
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoryManagement;
