
import axios from 'https://esm.sh/axios@1.7.9';
import { AuthResponse, User, DashboardStats, UserDTO, RoleDTO, ApiResponse } from '../types';
import { getCookie, eraseCookie } from '../utils/cookieHelper';

// Centralized URLs
export const BASE_URL = 'http://localhost:8080/api';
export const WS_URL = 'http://localhost:8080/ws-clinic';

/**
 * Axios Instance Configuration
 */
const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

/**
 * Request Interceptor for Authorization
 */
api.interceptors.request.use(config => {
  const token = getCookie('sspd_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

/**
 * Response Interceptor for standardizing SSPD API Responses
 */
api.interceptors.response.use(
  response => response.data,
  error => {
    const apiError = error.response?.data || { success: false, message: error.message };
    return Promise.reject(apiError);
  }
);

export const authService = {
  login: async (usernameOremail: string, password: string): Promise<ApiResponse<AuthResponse>> => {
    return api.post('/v1/auth/login', { usernameOremail, password });
  },

  logout: () => {
    eraseCookie('sspd_token');
    eraseCookie('sspd_user');
  },

  getCurrentUser: (): User | null => {
    const saved = getCookie('sspd_user');
    return saved ? JSON.parse(saved) : null;
  }
};

export const dashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    try {
      const response = await api.get<any, ApiResponse<DashboardStats>>('/v1/dashboard/stats');
      return response.data;
    } catch (e) {
      console.warn("Dashboard API failed, using mock data");
      return {
        totalSales: 12400000,
        totalPurchases: 8500000,
        totalServices: 48,
        totalCustomers: 124,
        recentSales: [
          { id: 1, saleCode: 'INV-2024001', customerName: 'U Aung Myint', amount: 125000, date: '2 hours ago', status: 'Paid' },
          { id: 2, saleCode: 'INV-2024002', customerName: 'Daw Aye Aye', amount: 45000, date: '5 hours ago', status: 'Partial' },
          { id: 3, saleCode: 'INV-2024003', customerName: 'Ko Kyaw Swar', amount: 320000, date: '1 day ago', status: 'Pending' },
          { id: 4, saleCode: 'INV-2024004', customerName: 'Ma Hla Hla', amount: 89000, date: '1 day ago', status: 'Paid' },
        ]
      };
    }
  }
};

export const rbacService = {
  getUsers: async (): Promise<UserDTO[]> => {
    try {
      const response = await api.get<any, ApiResponse<UserDTO[]>>('/v1/rbac/users');
      return response.data;
    } catch (e) {
      return [
        { id: 1, username: 'admin', email: 'admin@ssdp.com', authProvider: 'LOCAL', isActive: true, roles: ['ROLE_ADMIN'] },
        { id: 2, username: 'manager_aye', email: 'aye@ssdp.com', authProvider: 'LOCAL', isActive: true, roles: ['ROLE_MANAGER'] },
        { id: 3, username: 'staff_kyaw', email: 'kyaw@ssdp.com', authProvider: 'LOCAL', isActive: false, roles: ['ROLE_STAFF'] },
      ];
    }
  },
  getRoles: async (): Promise<RoleDTO[]> => {
    try {
      const response = await api.get<any, ApiResponse<RoleDTO[]>>('/v1/rbac/roles');
      return response.data;
    } catch (e) {
      return [
        { id: 1, name: 'ROLE_ADMIN', description: 'Full access to all modules', permissions: [{ id: 1, name: 'ALL_ACCESS', description: '' }] },
        { id: 2, name: 'ROLE_MANAGER', description: 'Manage sales and inventory', permissions: [{ id: 2, name: 'WRITE_SALES', description: '' }] },
      ];
    }
  }
};

export const entityService = {
  getServices: () => api.get<any, ApiResponse<any[]>>('/v1/services').then((res: any) => res.data),
  getProducts: () => api.get<any, ApiResponse<any[]>>('/v1/products').then((res: any) => res.data),
  getCustomers: () => api.get<any, ApiResponse<any[]>>('/v1/customers').then((res: any) => res.data),
  getStaff: () => api.get<any, ApiResponse<any[]>>('/v1/staff').then((res: any) => res.data),
};
