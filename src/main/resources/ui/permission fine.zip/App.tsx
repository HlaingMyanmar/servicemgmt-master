
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import RoleManagement from './pages/RoleManagement';
import PermissionManagement from './pages/PermissionManagement';
import Layout from './components/Layout';
import { User, AppRoute } from './types';
import { setCookie, eraseCookie } from './utils/cookieHelper';
import { authService } from './services/api';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    /**
     * REQUIREMENT: Force logout on reload.
     * We clear the session cookies immediately when the app component mounts.
     * Since mounting only happens on initial load/reload, this forces a fresh login.
     */
    authService.logout();
    
    // Explicitly clear any other potential persistence
    sessionStorage.clear();
    localStorage.clear();
    
    setLoading(false);
  }, []);

  const handleLoginSuccess = (userData: User, token: string) => {
    setUser(userData);
    /**
     * Store in session cookies.
     * These will be available for the current duration of the app state.
     */
    setCookie('sspd_user', JSON.stringify(userData));
    setCookie('sspd_token', token);
  };

  const handleLogout = () => {
    // REQUIREMENT: eraseCookie on logout
    authService.logout();
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route 
          path={AppRoute.LOGIN} 
          element={!user ? <Login onLoginSuccess={handleLoginSuccess} /> : <Navigate to={AppRoute.DASHBOARD} />} 
        />
        <Route 
          path={AppRoute.DASHBOARD} 
          element={user ? <Layout user={user} onLogout={handleLogout}><Dashboard /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.USERS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><UserManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.ROLES} 
          element={user ? <Layout user={user} onLogout={handleLogout}><RoleManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route 
          path={AppRoute.PERMISSIONS} 
          element={user ? <Layout user={user} onLogout={handleLogout}><PermissionManagement /></Layout> : <Navigate to={AppRoute.LOGIN} />} 
        />
        <Route path="*" element={<Navigate to={AppRoute.DASHBOARD} />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
