
import React, { useEffect, useState } from 'react';
import { rbacService } from '../services/api';
import { RoleDTO } from '../types';
import { Loader2, Plus, ShieldCheck, Key, Settings2 } from 'lucide-react';

const RoleManagement: React.FC = () => {
  const [roles, setRoles] = useState<RoleDTO[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    rbacService.getRoles().then(data => {
      setRoles(data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-indigo-600" size={40} /></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">System Roles</h2>
          <p className="text-slate-500 text-sm">Define and manage permission sets for different job functions.</p>
        </div>
        <button className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2">
          <Plus size={18} /> Create Role
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {roles.map(role => (
          <div key={role.id} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg">
                <Settings2 size={18} />
              </button>
            </div>
            
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                <ShieldCheck size={28} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">{role.name}</h3>
                <p className="text-xs text-slate-400 font-medium">ID: #{role.id}</p>
              </div>
            </div>

            <p className="text-sm text-slate-600 mb-6 line-clamp-2 min-h-[40px]">
              {role.description || "No description provided for this security role."}
            </p>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">
                <span>Assigned Permissions</span>
                <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">{role.permissions.length}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {role.permissions.map(p => (
                  <span key={p.id} className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-50 text-slate-500 text-[10px] font-bold border border-slate-100">
                    <Key size={10} /> {p.name}
                  </span>
                ))}
                {role.permissions.length === 0 && <span className="text-[10px] text-slate-400 italic">No permissions assigned</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoleManagement;
