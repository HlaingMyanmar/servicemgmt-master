
import { api } from './api';
import { CustomerDTO, CustomerGroupDTO, ApiResponse } from '../types';

export const customerService = {
  getAll: async (): Promise<CustomerDTO[]> => {
    const res = await api.get<any, ApiResponse<CustomerDTO[]>>('/v1/customers/all');
    return res.data;
  },

  getPaginated: async (page: number = 0, size: number = 10): Promise<any> => {
    const res = await api.get<any, ApiResponse<any>>(`/v1/customers?page=${page}&size=${size}`);
    return res.data;
  },

  create: (customer: Partial<CustomerDTO>) => 
    api.post<any, ApiResponse<CustomerDTO>>('/v1/customers', customer).then((res: any) => res.data),
  
  update: (id: number, customer: Partial<CustomerDTO>) => 
    api.put<any, ApiResponse<CustomerDTO>>(`/v1/customers/${id}`, customer).then((res: any) => res.data),
  
  delete: (id: number) => api.delete<any, ApiResponse<void>>(`/v1/customers/${id}`).then((res: any) => res.data),

  search: (keyword: string) => api.get<any, ApiResponse<CustomerDTO[]>>(`/v1/customers/search?keyword=${keyword}`).then((res: any) => res.data),
};

export const customerGroupService = {
  getAll: async (): Promise<CustomerGroupDTO[]> => {
    const res = await api.get<any, ApiResponse<CustomerGroupDTO[]>>('/v1/customer-groups');
    return res.data;
  },
  create: (group: Partial<CustomerGroupDTO>) => api.post('/v1/customer-groups', group),
  update: (id: number, group: Partial<CustomerGroupDTO>) => api.put(`/v1/customer-groups/${id}`, group),
  delete: (id: number) => api.delete(`/v1/customer-groups/${id}`)
};
