
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { customerService, customerGroupService } from '../services/customerapiservice';
import { CustomerDTO, CustomerGroupDTO } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, X, 
  Users, Phone, Mail, MapPin, CreditCard,
  ChevronLeft, ChevronRight, ChevronDown, Save,
  AlertCircle, ClipboardList, RefreshCw, Star,
  Filter, RotateCcw, Wallet
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'sweetalert2';

const CustomerManagement: React.FC = () => {
  const [customers, setCustomers] = useState<CustomerDTO[]>([]);
  const [groups, setGroups] = useState<CustomerGroupDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<number | 'All'>('All');
  
  const [currentPage, setCurrentPage] = useState(0); 
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [totalElements, setTotalElements] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<CustomerDTO | null>(null);
  const [formData, setFormData] = useState<Partial<CustomerDTO>>({
    name: '',
    phone: '',
    email: '',
    address: '',
    customerGroupId: undefined,
    openingBalance: 0
  });
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [cPage, gData] = await Promise.all([
        customerService.getPaginated(currentPage, itemsPerPage),
        customerGroupService.getAll()
      ]);
      setCustomers(cPage.content);
      setGroups(gData);
      setTotalElements(cPage.totalElements);
      setTotalPages(cPage.totalPages);
    } catch (error) {
      console.error("Failed to load CRM data", error);
    } finally {
      setLoading(false);
    }
  }, [currentPage, itemsPerPage]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useWebsocket('/topic/customer', fetchData);

  const handleOpenModal = (customer?: CustomerDTO) => {
    if (customer) {
      setEditingCustomer(customer);
      setFormData({
        name: customer.name,
        phone: customer.phone || '',
        email: customer.email || '',
        address: customer.address || '',
        customerGroupId: customer.customerGroupId,
        openingBalance: customer.openingBalance
      });
    } else {
      setEditingCustomer(null);
      setFormData({
        name: '',
        phone: '',
        email: '',
        address: '',
        customerGroupId: groups.length > 0 ? groups[0].id : undefined,
        openingBalance: 0
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingCustomer) {
        await customerService.update(editingCustomer.id, formData);
      } else {
        await customerService.create(formData);
      }
      setIsModalOpen(false);
      fetchData();
      Swal.fire({ icon: 'success', title: 'Registry Updated', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message || 'Operation failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Remove Customer?',
      text: "Warning: Deleting a customer will also remove their transaction history reference.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, Delete'
    });

    if (result.isConfirmed) {
      try {
        await customerService.delete(id);
        fetchData();
        Swal.fire({ icon: 'success', title: 'Deleted Successfully', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
      } catch (error: any) {
        Swal.fire('Restricted', 'Active accounts with transactions cannot be deleted.', 'error');
      }
    }
  };

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);
    if (val.trim() === '') {
      fetchData();
    } else if (val.length >= 2) {
      try {
        const results = await customerService.search(val);
        setCustomers(results);
        setTotalPages(1);
      } catch (err) {}
    }
  };

  const totalOutstanding = useMemo(() => {
    return customers.reduce((sum, c) => sum + Math.max(0, c.currentBalance), 0);
  }, [customers]);

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-indigo-600" size={32} /></div>;

  return (
    <div className="space-y-4 animate-in fade-in duration-400 h-full flex flex-col overflow-hidden text-left">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 px-1">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-sky-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-sky-100 shrink-0">
            <Users size={24} />
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-6">
            <div>
              <h2 className="text-base font-black text-slate-800 tracking-tight uppercase">Customer Directory</h2>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5 flex items-center gap-1.5">
                <Star size={10} className="text-sky-400" /> CRM & Loyalty Management
              </p>
            </div>

            <div className="flex items-center gap-3 px-5 py-2 bg-emerald-50 border border-emerald-100 rounded-2xl">
              <div className="w-8 h-8 bg-emerald-500 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/10">
                <Wallet size={16} />
              </div>
              <div className="text-left">
                <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest leading-none mb-1">Total Outstanding</p>
                <p className="text-[14px] font-black text-slate-800 tracking-tight leading-none">
                  {totalOutstanding.toLocaleString()} <span className="text-[10px] text-slate-400 ml-0.5 uppercase">Ks</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <button 
          onClick={() => handleOpenModal()} 
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase shadow-xl shadow-indigo-100 active:scale-95 transition-all flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus size={18} /> New Registration
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm space-y-4 mx-1">
        <div className="flex flex-col lg:flex-row gap-5">
          <div className="relative flex-1 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Search by name, phone or email..." 
              value={searchTerm}
              onChange={handleSearch}
              className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none text-[13px] font-bold focus:bg-white focus:border-indigo-500 transition-all shadow-sm"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 border border-slate-200 rounded-2xl">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-3">Classification</span>
              <select 
                value={selectedGroupId}
                onChange={(e) => setSelectedGroupId(e.target.value === 'All' ? 'All' : Number(e.target.value))}
                className="bg-transparent text-[10px] font-black text-indigo-600 outline-none uppercase cursor-pointer px-3"
              >
                <option value="All">All Groups</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>

            <button onClick={() => {setSearchTerm(''); setSelectedGroupId('All'); fetchData();}} className="p-3.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all border border-transparent hover:border-rose-100 bg-white shadow-sm">
              <RotateCcw size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="bg-white rounded-[2rem] shadow-2xl shadow-slate-200/50 border border-slate-200 flex flex-col flex-1 overflow-hidden mx-1">
        <div className="flex-1 overflow-auto custom-scrollbar relative">
          <table className="w-full text-left border-collapse min-w-[1100px]">
            <thead className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-sm border-b border-slate-200 shadow-sm">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Client Profile</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact Point</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Group</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Account Balance</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Action Hub</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customers.length > 0 ? customers.map((customer) => (
                <tr key={customer.id} className="hover:bg-slate-50/50 transition-all group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-11 h-11 rounded-2xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 shadow-sm group-hover:bg-sky-600 group-hover:text-white transition-all">
                        <Star size={22} />
                      </div>
                      <div className="text-left">
                        <p className="text-[14px] font-black text-slate-800 tracking-tight leading-tight">{customer.name}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{customer.customerCode}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-5">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2">
                        <Phone size={12} className="text-slate-300" />
                        <span className="text-[11px] font-bold text-slate-600">{customer.phone || 'No Phone'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail size={12} className="text-slate-300" />
                        <span className="text-[10px] font-medium text-slate-400 truncate max-w-[150px]">{customer.email || 'No Email'}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-5">
                    <span className="px-3 py-1 rounded-full bg-slate-50 text-slate-500 border border-slate-200 text-[10px] font-black uppercase tracking-widest">
                      {customer.customerGroupName || 'Regular'}
                    </span>
                  </td>
                  <td className="px-4 py-5 text-right">
                    <div className="flex flex-col items-end">
                      <span className={`text-[14px] font-black tabular-nums ${customer.currentBalance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {customer.currentBalance.toLocaleString()} <span className="text-[10px] ml-0.5 uppercase">Ks</span>
                      </span>
                      {customer.openingBalance > 0 && (
                        <p className="text-[9px] text-slate-300 font-bold uppercase tracking-tighter">OB: {customer.openingBalance.toLocaleString()}</p>
                      )}
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button onClick={() => handleOpenModal(customer)} className="p-2.5 bg-indigo-50 text-indigo-600 border border-indigo-100 hover:bg-indigo-600 hover:text-white rounded-xl transition-all shadow-sm">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => handleDelete(customer.id)} className="p-2.5 bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-600 hover:text-white rounded-xl transition-all shadow-sm">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-6 py-40 text-center">
                    <div className="flex flex-col items-center gap-5">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center border border-dashed border-slate-200">
                        <Users className="text-slate-200" size={40} />
                      </div>
                      <p className="text-sm font-black uppercase tracking-widest text-slate-400 italic">No Customers Found</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalElements > 0 && (
          <div className="sticky bottom-0 z-30 px-10 py-6 bg-white border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="w-full md:w-auto text-center md:text-left order-2 md:order-1">
              <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                Client Index <span className="w-6 h-[1px] bg-slate-200"></span> 
                Found <span className="text-indigo-600">{totalElements}</span> Profiles
              </span>
            </div>

            <div className="w-full md:w-auto flex flex-col sm:flex-row items-center justify-center gap-5 order-1 md:order-2">
              <select 
                value={itemsPerPage} onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(0); }}
                className="appearance-none bg-slate-50 border border-slate-200 rounded-xl px-5 py-2.5 pr-12 text-[11px] font-black text-slate-600 outline-none focus:bg-white focus:border-indigo-500 cursor-pointer shadow-sm transition-all"
              >
                <option value={10}>Show 10</option>
                <option value={25}>Show 25</option>
                <option value={50}>Show 50</option>
              </select>

              <div className="flex items-center gap-2">
                <button disabled={currentPage === 0} onClick={() => setCurrentPage(prev => Math.max(prev - 1, 0))} className="p-3 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all shadow-sm active:scale-90"><ChevronLeft size={18} /></button>
                <div className="flex gap-1.5">
                  {[...Array(totalPages)].map((_, i) => (
                    <button key={i} onClick={() => setCurrentPage(i)} className={`min-w-[42px] h-11 rounded-xl text-[12px] font-black transition-all ${currentPage === i ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 border-indigo-600' : 'bg-white border border-slate-100 text-slate-500 hover:bg-slate-50'}`}>{i + 1}</button>
                  ))}
                </div>
                <button disabled={currentPage === totalPages - 1} onClick={() => setCurrentPage(prev => prev + 1)} className="p-3 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all shadow-sm active:scale-90"><ChevronRight size={18} /></button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Registration Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200 text-left">
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl border border-slate-200 animate-in zoom-in-95 overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="text-left">
                <h3 className="text-[15px] font-black text-slate-800 uppercase tracking-tight">{editingCustomer ? 'Update Profile' : 'New Client Registration'}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-widest italic">Identity & Credit Profile</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white hover:shadow-md rounded-xl transition-all"><X size={20} className="text-slate-400" /></button>
            </div>
            
            <form onSubmit={handleSave} className="p-8 space-y-6 text-left max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-left block">Full Name / Business Name</label>
                  <div className="relative group">
                    <Star className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <input 
                      type="text" required value={formData.name} 
                      onChange={(e) => setFormData({...formData, name: e.target.value})} 
                      className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-sm" 
                      placeholder="Enter legal name"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-left block">Primary Phone</label>
                  <div className="relative group">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <input 
                      type="text" required value={formData.phone} 
                      onChange={(e) => setFormData({...formData, phone: e.target.value})} 
                      className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-sm" 
                      placeholder="e.g. 09xxxxxxxx"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-left block">Email (Optional)</label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <input 
                      type="email" value={formData.email} 
                      onChange={(e) => setFormData({...formData, email: e.target.value})} 
                      className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-sm" 
                      placeholder="client@domain.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-left block">Customer Group</label>
                  <div className="relative group">
                    <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <select 
                      required value={formData.customerGroupId || ''} 
                      onChange={(e) => setFormData({...formData, customerGroupId: Number(e.target.value)})} 
                      className="w-full pl-12 pr-10 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 appearance-none shadow-sm transition-all"
                    >
                      <option value="" disabled>Choose Category</option>
                      {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                {!editingCustomer && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-emerald-600 block">Initial Balance (MMK)</label>
                    <div className="relative group">
                      <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-300 group-focus-within:text-emerald-500 transition-colors" size={16} />
                      <input 
                        type="number" value={formData.openingBalance} 
                        onChange={(e) => setFormData({...formData, openingBalance: Number(e.target.value)})} 
                        className="w-full pl-12 pr-5 py-4 bg-emerald-50/30 border border-emerald-100 rounded-2xl text-[12px] font-bold outline-none focus:border-emerald-500 focus:bg-white transition-all shadow-sm" 
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 text-left block">Geographic Address</label>
                <div className="relative group">
                  <MapPin className="absolute left-4 top-4 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                  <textarea 
                    rows={3} value={formData.address} 
                    onChange={(e) => setFormData({...formData, address: e.target.value})} 
                    className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 shadow-sm transition-all resize-none" 
                    placeholder="Enter full physical location..."
                  />
                </div>
              </div>

              {editingCustomer && (
                <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-start gap-3">
                  <AlertCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-left">
                    <p className="text-[11px] font-black text-amber-900 uppercase tracking-tight leading-none mb-1">Live Credit Position</p>
                    <p className="text-[16px] font-black text-slate-800 tabular-nums">{editingCustomer.currentBalance.toLocaleString()} MMK</p>
                    <p className="text-[9px] text-slate-400 font-bold mt-1 uppercase">Updates automatically through invoices and receipts.</p>
                  </div>
                </div>
              )}

              <div className="flex gap-4 pt-4 shrink-0">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 border border-slate-200 rounded-[1.25rem] text-[11px] font-black uppercase tracking-widest bg-white text-slate-500 hover:bg-slate-50 transition-all shadow-sm">Discard</button>
                <button type="submit" disabled={saving} className="flex-[2] py-4 bg-indigo-600 text-white rounded-[1.25rem] text-[11px] font-black uppercase tracking-widest shadow-2xl shadow-indigo-600/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2 hover:bg-indigo-700">
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} Finalize Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerManagement;
