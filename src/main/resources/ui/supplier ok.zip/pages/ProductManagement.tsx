
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { productService } from '../services/productapiservice';
import { brandService } from '../services/brandapiservice';
import { categoryService } from '../services/categoryapiservice';
import { unitService } from '../services/unitapiservice';
import { productSerialService } from '../services/productserialapiservice';
import { ProductDTO, BrandDTO, CategoryDTO, UnitDTO, ProductType, ProductSerialDTO, SerialStatus } from '../types';
import { 
  Loader2, Plus, Search, Trash2, Edit2, X, 
  Box, ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  Tag, Package, Ruler, Layers, DollarSign,
  Save, Hash, Send, Barcode,
  CheckCircle2, AlertCircle, Filter, RotateCcw,
  ClipboardList, Eye, Info, LayoutList, Wallet,
  Settings2
} from 'lucide-react';
import { useWebsocket } from '../hooks/useWebsocket';
import Swal from 'https://esm.sh/sweetalert2@11.15.10';

interface CategoryOption {
  id: number;
  displayName: string;
}

interface ProductGroup {
  groupId: string;
  displayName: string;
  brandName: string;
  categoryName: string;
  brandId?: number;
  categoryId?: number;
  unitName: string;
  products: ProductDTO[]; 
  totalAvailable: number;
  totalUnits: number;
  groupTotalPrice: number;
}

const ProductManagement: React.FC = () => {
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [brands, setBrands] = useState<BrandDTO[]>([]);
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [units, setUnits] = useState<UnitDTO[]>([]);
  const [allSerials, setAllSerials] = useState<ProductSerialDTO[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCondition, setFilterCondition] = useState<'All' | 'New' | 'Second'>('All');
  const [filterStatus, setFilterStatus] = useState<'All' | 'In Stock' | 'Out of Stock'>('All');
  
  // Local filter for the nested table rows (Condition filter)
  const [nestedConditionFilter, setNestedConditionFilter] = useState<'All' | 'New' | 'Second'>('All');

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSerialModalOpen, setIsSerialModalOpen] = useState(false);
  const [selectedProductForSerial, setSelectedProductForSerial] = useState<ProductDTO | null>(null);
  const [editingProduct, setEditingProduct] = useState<ProductDTO | null>(null);
  const [newSerialInput, setNewSerialInput] = useState('');
  
  const [formData, setFormData] = useState<Partial<ProductDTO>>({
    name: '',
    productType: ProductType.NEW,
    sellingPrice: 0,
    remark: '',
    categoryId: undefined,
    brandId: undefined,
    unitId: undefined
  });
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [pData, bData, cTreeData, uData, sData] = await Promise.all([
        productService.getAll(),
        brandService.getAll(),
        categoryService.getTree(),
        unitService.getAll(),
        productSerialService.getAll()
      ]);
      setProducts(pData);
      setBrands(bData.filter(b => b.isActive));
      setCategories(cTreeData);
      setUnits(uData);
      setAllSerials(sData);
    } catch (error) {
      console.error("Failed to load inventory data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useWebsocket('/topic/product', fetchData);
  useWebsocket('/topic/productSerial', fetchData);

  const getCategoryOptions = useCallback((nodes: CategoryDTO[], level = 0): CategoryOption[] => {
    return nodes.reduce((acc: CategoryOption[], node) => {
      const indentation = "\u00A0\u00A0".repeat(level * 2);
      const prefix = level > 0 ? "↳ " : "";
      acc.push({ id: node.id, displayName: `${indentation}${prefix}${node.name}` });
      if (node.children && node.children.length > 0) {
        acc.push(...getCategoryOptions(node.children, level + 1));
      }
      return acc;
    }, []);
  }, []);

  const flatCategoryOptions = useMemo(() => getCategoryOptions(categories), [categories, getCategoryOptions]);

  // Calculate Total Value of all AVAILABLE Serial Units
  const totalAvailableStockValue = useMemo(() => {
    return allSerials
      .filter(s => s.status === SerialStatus.AVAILABLE)
      .reduce((sum, s) => {
        const product = products.find(p => p.id === s.productId);
        return sum + (product?.sellingPrice || 0);
      }, 0);
  }, [allSerials, products]);

  const productGroups = useMemo(() => {
    const s = searchTerm.toLowerCase().trim();
    const groupsMap = new Map<string, ProductGroup>();
    
    products.forEach(p => {
      const normalizedName = p.name.toLowerCase().replace(/\s+/g, '');
      const brandId = p.brandId || 0;
      const categoryId = p.categoryId || 0;
      const groupId = `${normalizedName}-${brandId}-${categoryId}`;

      const serials = allSerials.filter(sr => sr.productId === p.id);
      const availableCount = serials.filter(sr => sr.status === SerialStatus.AVAILABLE).length;

      if (!groupsMap.has(groupId)) {
        groupsMap.set(groupId, {
          groupId,
          displayName: p.name,
          brandName: p.brandName || 'Unknown',
          categoryName: p.categoryName || 'General',
          brandId: p.brandId,
          categoryId: p.categoryId,
          unitName: p.unitName || '',
          products: [p],
          totalAvailable: availableCount,
          totalUnits: serials.length,
          groupTotalPrice: p.sellingPrice
        });
      } else {
        const group = groupsMap.get(groupId)!;
        group.products.push(p);
        group.totalAvailable += availableCount;
        group.totalUnits += serials.length;
        group.groupTotalPrice += p.sellingPrice;
      }
    });

    return Array.from(groupsMap.values()).filter(group => {
      const matchesSearch = !s || 
        group.displayName.toLowerCase().includes(s) || 
        group.brandName.toLowerCase().includes(s) ||
        group.categoryName.toLowerCase().includes(s) ||
        group.products.some(p => p.productCode.toLowerCase().includes(s)) ||
        allSerials.filter(sr => group.products.some(p => p.id === sr.productId))
          .some(sn => sn.serialNumber.toLowerCase().includes(s));

      const matchesCondition = filterCondition === 'All' || 
        group.products.some(p => p.productType === filterCondition);

      const matchesStatus = filterStatus === 'All' || 
        (filterStatus === 'In Stock' && group.totalAvailable > 0) || 
        (filterStatus === 'Out of Stock' && group.totalAvailable === 0);

      return matchesSearch && matchesCondition && matchesStatus;
    });
  }, [products, allSerials, searchTerm, filterCondition, filterStatus]);

  useEffect(() => {
    setCurrentPage(1);
    setExpandedGroups(new Set());
  }, [searchTerm, filterCondition, filterStatus]);

  const toggleGroup = (groupId: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) newExpanded.delete(groupId);
    else newExpanded.add(groupId);
    setExpandedGroups(newExpanded);
  };

  const totalPages = Math.ceil(productGroups.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedGroups = productGroups.slice(startIndex, startIndex + itemsPerPage);

  const handleOpenModal = (product?: ProductDTO) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        productType: product.productType,
        sellingPrice: product.sellingPrice,
        remark: product.remark || '',
        categoryId: product.categoryId,
        brandId: product.brandId,
        unitId: product.unitId
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: '',
        productType: ProductType.NEW,
        sellingPrice: 0,
        remark: '',
        categoryId: undefined,
        brandId: undefined,
        unitId: undefined
      });
    }
    setIsModalOpen(true);
  };

  const handleOpenSerialModal = (product: ProductDTO) => {
    setSelectedProductForSerial(product);
    setNewSerialInput('');
    setIsSerialModalOpen(true);
  };

  const handleAddSerial = async () => {
    if (!newSerialInput.trim() || !selectedProductForSerial) return;
    setSaving(true);
    try {
      await productSerialService.create({
        serialNumber: newSerialInput.trim().toUpperCase(),
        status: SerialStatus.AVAILABLE,
        productId: selectedProductForSerial.id
      });
      setNewSerialInput('');
      fetchData();
      Swal.fire({ icon: 'success', title: 'Serial Registered', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (err: any) {
      Swal.fire('Conflict', 'This Serial Number is already in use.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: any = { ...formData };
      if (editingProduct) {
        payload.productCode = editingProduct.productCode;
        await productService.update(editingProduct.id, payload);
      } else {
        payload.productCode = "AUTO-" + Date.now().toString().slice(-6);
        await productService.create(payload);
      }
      setIsModalOpen(false);
      fetchData();
      Swal.fire({ icon: 'success', title: 'Registry Saved', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
    } catch (error: any) {
      Swal.fire('Error', error.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: 'Remove Registry?',
      text: "Warning: All units linked to this entry will be lost.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Confirm Delete'
    });
    if (result.isConfirmed) {
      try {
        await productService.delete(id);
        fetchData();
        Swal.fire({ icon: 'success', title: 'Removed', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  const handleDeleteSerial = async (id: number) => {
    const result = await Swal.fire({
      title: 'Delete Unit?',
      text: "Permanent action.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Delete'
    });
    if (result.isConfirmed) {
      try {
        await productSerialService.delete(id);
        fetchData();
        Swal.fire({ icon: 'success', title: 'Deleted', toast: true, position: 'top-end', showConfirmButton: false, timer: 1500 });
      } catch (error: any) {
        Swal.fire('Error', error.message, 'error');
      }
    }
  };

  if (loading) return (
    <div className="h-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-600" size={32} />
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-400 h-full flex flex-col overflow-hidden text-left">
      {/* Header with Dashboard Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0 px-1">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-100 shrink-0">
            <LayoutList size={24} />
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div>
              <h2 className="text-base font-black text-slate-800 tracking-tight uppercase">Product Master Ledger</h2>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5 flex items-center gap-1.5">
                <ClipboardList size={10} className="text-indigo-400" /> Case-Insensitive Smart Grouping
              </p>
            </div>
            
            {/* Real-time Financial Value Box */}
            <div className="flex items-center gap-3 px-5 py-2.5 bg-emerald-50 border border-emerald-100 rounded-2xl shadow-sm animate-in zoom-in-95 duration-500">
              <div className="w-9 h-9 bg-emerald-500 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <Wallet size={18} />
              </div>
              <div className="text-left">
                <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest leading-none mb-1">Total Available Value</p>
                <p className="text-[15px] font-black text-slate-800 tracking-tight leading-none">
                  {totalAvailableStockValue.toLocaleString()} <span className="text-[10px] text-slate-400 ml-0.5 font-bold uppercase">Ks</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <button 
          onClick={() => handleOpenModal()} 
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase shadow-xl shadow-indigo-100 active:scale-95 transition-all flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus size={18} /> Add New Entry
        </button>
      </div>

      {/* Primary Filters */}
      <div className="bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm space-y-4 mx-1">
        <div className="flex flex-col lg:flex-row gap-5">
          <div className="relative flex-1 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Search by name, code, brand or serial..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none text-[13px] font-bold focus:bg-white focus:border-indigo-500 transition-all shadow-sm"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 border border-slate-200 rounded-2xl">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-3">Condition</span>
              {['All', 'New', 'Second'].map((type) => (
                <button
                  key={type}
                  onClick={() => setFilterCondition(type as any)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${
                    filterCondition === type ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-indigo-600'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            <button onClick={() => {setSearchTerm(''); setFilterCondition('All'); setFilterStatus('All');}} className="p-3.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all border border-transparent hover:border-rose-100 bg-white shadow-sm">
              <RotateCcw size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Ledger Groups */}
      <div className="bg-white rounded-[2rem] shadow-2xl shadow-slate-200/50 border border-slate-200 flex flex-col flex-1 overflow-hidden mx-1">
        <div className="flex-1 overflow-auto custom-scrollbar relative">
          <table className="w-full text-left border-collapse min-w-[1200px]">
            <thead className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-sm border-b border-slate-200 shadow-sm">
              <tr>
                <th className="w-16 px-4"></th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Master Product Group</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Brand / Category</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">In-Stock Units</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Standard Price (Total)</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Inventory Logic</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedGroups.length > 0 ? paginatedGroups.map((group) => {
                const isExpanded = expandedGroups.has(group.groupId);
                return (
                  <React.Fragment key={group.groupId}>
                    <tr className={`transition-all duration-300 group ${isExpanded ? 'bg-indigo-50/40' : 'hover:bg-slate-50/50'}`}>
                      <td className="px-4 text-center">
                        <button 
                          onClick={() => toggleGroup(group.groupId)}
                          className={`p-2 rounded-xl transition-all ${isExpanded ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-100'}`}
                        >
                          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                        </button>
                      </td>
                      <td className="px-4 py-5">
                        <div className="flex items-center gap-4">
                          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all shadow-sm ${isExpanded ? 'bg-indigo-600 text-white' : 'bg-indigo-50 text-indigo-600 border border-indigo-100'}`}>
                            <Package size={22} />
                          </div>
                          <div>
                            <p className="text-[14px] font-black text-slate-800 tracking-tight">{group.displayName}</p>
                            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                               {group.products.length} Configuration Entry(s)
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-5">
                        <div className="flex flex-col gap-1.5">
                          <div className="flex items-center gap-2">
                            <Tag size={12} className="text-indigo-500" />
                            <span className="text-[10px] font-black text-slate-600 uppercase tracking-tight">{group.brandName}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Layers size={12} className="text-slate-300" />
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{group.categoryName}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-5 text-center">
                        <div className="flex justify-center">
                          {group.totalAvailable > 0 ? (
                            <span className="px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100 text-[10px] font-black uppercase tracking-wider flex items-center gap-2 shadow-sm">
                              <CheckCircle2 size={14} /> {group.totalAvailable} Units
                            </span>
                          ) : (
                            <span className="px-4 py-1.5 rounded-full bg-rose-50 text-rose-600 border border-rose-100 text-[10px] font-black uppercase tracking-wider flex items-center gap-2 shadow-sm">
                              <AlertCircle size={14} /> Out of Stock
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-5 text-right">
                        <span className="text-[14px] font-black text-slate-800 tabular-nums">
                          {group.groupTotalPrice.toLocaleString()} <span className="text-[10px] text-slate-400 ml-0.5 font-bold uppercase">Ks</span>
                        </span>
                      </td>
                      <td className="px-8 py-5 text-right">
                         <div className="flex justify-end gap-2">
                            <button 
                              onClick={() => toggleGroup(group.groupId)}
                              className="px-4 py-2 bg-white border border-slate-200 hover:bg-indigo-600 hover:text-white text-slate-600 text-[10px] font-black uppercase rounded-xl transition-all flex items-center gap-2 shadow-sm active:scale-95"
                            >
                              <Eye size={14} /> {isExpanded ? 'Close Map' : 'Expand Breakdown'}
                            </button>
                         </div>
                      </td>
                    </tr>
                    
                    {/* NESTED BREAKDOWN TABLE WITH INTEGRATED FILTER */}
                    {isExpanded && (
                      <tr className="bg-slate-50/30">
                        <td colSpan={6} className="px-8 py-6">
                          <div className="bg-white rounded-[1.5rem] border border-slate-200 shadow-2xl overflow-hidden animate-in slide-in-from-top-2 duration-300">
                            <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                               <div className="flex items-center gap-2">
                                 <Info size={14} className="text-indigo-500" />
                                 <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Entry Breakdown Ledger</span>
                               </div>
                               <div className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-xl shadow-sm">
                                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Filter:</span>
                                  <select 
                                    value={nestedConditionFilter} 
                                    onChange={(e) => setNestedConditionFilter(e.target.value as any)}
                                    className="bg-transparent text-[10px] font-black text-indigo-600 outline-none uppercase cursor-pointer"
                                  >
                                    <option value="All">All Conditions</option>
                                    <option value="New">New Only</option>
                                    <option value="Second">Second Only</option>
                                  </select>
                               </div>
                            </div>
                            <table className="w-full text-left">
                              <thead className="bg-slate-100/50">
                                <tr>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Entry Code</th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">
                                    <div className="flex items-center justify-center gap-2">
                                      Condition <Filter size={10} className="text-indigo-400" />
                                    </div>
                                  </th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Registry Remarks</th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Serial Number</th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Status</th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Selling Price</th>
                                  <th className="px-6 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                {group.products
                                  .filter(p => nestedConditionFilter === 'All' || p.productType === nestedConditionFilter)
                                  .map(p => {
                                  const pSerials = allSerials.filter(sr => sr.productId === p.id);
                                  
                                  if (pSerials.length === 0) {
                                    return (
                                      <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group/row">
                                        <td className="px-6 py-4 font-black text-indigo-600 text-[11px]">{p.productCode}</td>
                                        <td className="px-6 py-4 text-center">
                                          <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider border ${
                                            p.productType === ProductType.NEW ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                                          }`}>{p.productType}</span>
                                        </td>
                                        <td className="px-6 py-4"><p className="text-[10px] text-slate-400 italic truncate max-w-[150px]">{p.remark || '-'}</p></td>
                                        <td className="px-6 py-4 text-[10px] text-rose-400 font-bold uppercase italic tracking-tighter">No Units Linked</td>
                                        <td className="px-6 py-4 text-center text-slate-300 font-black text-[9px]">-</td>
                                        <td className="px-6 py-4 text-right font-black text-slate-800 text-[12px]">{p.sellingPrice.toLocaleString()}</td>
                                        <td className="px-6 py-4 text-right">
                                          <div className="flex justify-end gap-2">
                                            <button onClick={() => handleOpenSerialModal(p)} title="Add Serial" className="p-2 bg-emerald-50 text-emerald-600 border border-emerald-100 hover:bg-emerald-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Hash size={14} /></button>
                                            <button onClick={() => handleOpenModal(p)} title="Edit Spec" className="p-2 bg-indigo-50 text-indigo-600 border border-indigo-100 hover:bg-indigo-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Edit2 size={14} /></button>
                                            <button onClick={() => handleDelete(p.id)} title="Delete Entry" className="p-2 bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Trash2 size={14} /></button>
                                          </div>
                                        </td>
                                      </tr>
                                    );
                                  }

                                  return pSerials.map((s, idx) => (
                                    <tr key={s.id} className="hover:bg-slate-50/50 transition-colors group/row">
                                      <td className="px-6 py-4">
                                        {idx === 0 ? <span className="font-black text-indigo-600 text-[11px]">{p.productCode}</span> : <span className="text-slate-200 font-bold ml-2">↳</span>}
                                      </td>
                                      <td className="px-6 py-4 text-center">
                                        {idx === 0 ? (
                                          <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider border ${
                                            p.productType === ProductType.NEW ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                                          }`}>{p.productType}</span>
                                        ) : <span className="text-[9px] text-slate-300 italic uppercase tracking-tighter">Spec-Ref</span>}
                                      </td>
                                      <td className="px-6 py-4">
                                        {idx === 0 ? <p className="text-[10px] text-slate-400 italic truncate max-w-[150px]">{p.remark || '-'}</p> : <span className="text-slate-200">"</span>}
                                      </td>
                                      <td className="px-6 py-4 font-black text-slate-700 text-[11px] tracking-tight">{s.serialNumber}</td>
                                      <td className="px-6 py-4 text-center">
                                        <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider border ${
                                          s.status === SerialStatus.AVAILABLE ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-50 text-slate-500 border-slate-200'
                                        }`}>{s.status.replace(/_/g, ' ')}</span>
                                      </td>
                                      <td className="px-6 py-4 text-right font-black text-slate-800 text-[12px]">
                                        {idx === 0 ? p.sellingPrice.toLocaleString() : <span className="text-slate-300 font-normal">"</span>}
                                      </td>
                                      <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end gap-2">
                                          {idx === 0 ? (
                                            <>
                                              <button onClick={() => handleOpenSerialModal(p)} title="Add Serials" className="p-2 bg-emerald-50 text-emerald-600 border border-emerald-100 hover:bg-emerald-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Plus size={14} /></button>
                                              <button onClick={() => handleOpenModal(p)} title="Edit Spec" className="p-2 bg-indigo-50 text-indigo-600 border border-indigo-100 hover:bg-indigo-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Edit2 size={14} /></button>
                                              <button onClick={() => handleDelete(p.id)} title="Delete Spec" className="p-2 bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-600 hover:text-white rounded-xl transition-all shadow-md active:scale-95"><Trash2 size={14} /></button>
                                            </>
                                          ) : (
                                            <button onClick={() => handleDeleteSerial(s.id)} title="Remove Unit" className="p-2 text-rose-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={12} /></button>
                                          )}
                                        </div>
                                      </td>
                                    </tr>
                                  ));
                                })}
                                {group.products.filter(p => nestedConditionFilter === 'All' || p.productType === nestedConditionFilter).length === 0 && (
                                  <tr>
                                    <td colSpan={7} className="px-6 py-10 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest italic">
                                      No entries match the condition: {nestedConditionFilter}
                                    </td>
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              }) : (
                <tr>
                  <td colSpan={6} className="px-6 py-40 text-center text-slate-400">
                    <div className="flex flex-col items-center gap-5">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center border border-dashed border-slate-200">
                        <Filter className="text-slate-200" size={40} />
                      </div>
                      <p className="text-sm font-black uppercase tracking-widest text-slate-400 italic">No Matching Product Data</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Pagination */}
        {productGroups.length > 0 && (
          <div className="sticky bottom-0 z-30 px-10 py-6 bg-white border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-8 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
            <div className="w-full md:w-auto text-center md:text-left order-2 md:order-1">
              <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                Inventory Index <span className="w-6 h-[1px] bg-slate-200"></span> 
                Showing <span className="text-indigo-600">{startIndex + 1}-{Math.min(startIndex + itemsPerPage, productGroups.length)}</span> 
                of <span className="text-slate-800">{productGroups.length}</span> Master Groups
              </span>
            </div>

            <div className="w-full md:w-auto flex flex-col sm:flex-row items-center justify-center gap-5 order-1 md:order-2">
              <select 
                value={itemsPerPage} onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                className="appearance-none bg-slate-50 border border-slate-200 rounded-xl px-5 py-2.5 pr-12 text-[11px] font-black text-slate-600 outline-none focus:bg-white focus:border-indigo-500 cursor-pointer transition-all shadow-sm"
              >
                <option value={10}>Show 10</option>
                <option value={25}>Show 25</option>
                <option value={50}>Show 50</option>
              </select>

              <div className="flex items-center gap-2">
                <button disabled={currentPage === 1} onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} className="p-3 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all active:scale-90"><ChevronLeft size={18} /></button>
                <div className="flex gap-1.5">
                  {[...Array(totalPages)].map((_, i) => (
                    <button key={i} onClick={() => setCurrentPage(i + 1)} className={`min-w-[42px] h-11 rounded-xl text-[12px] font-black transition-all ${currentPage === i + 1 ? 'bg-indigo-600 text-white shadow-xl border-indigo-600' : 'bg-white border border-slate-100 text-slate-500 hover:bg-slate-100'}`}>{i + 1}</button>
                  ))}
                </div>
                <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))} className="p-3 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-30 transition-all active:scale-90"><ChevronRight size={18} /></button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Serial Management Modal */}
      {isSerialModalOpen && selectedProductForSerial && (
        <div className="fixed inset-0 z-[101] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200 text-left">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl border border-slate-200 animate-in zoom-in-95 flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between shrink-0 bg-slate-50/50">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="p-1.5 bg-indigo-600 text-white rounded-lg"><Hash size={14} /></div>
                  <h3 className="text-[14px] font-black text-slate-800 uppercase tracking-tight">Register Serial Units</h3>
                </div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest truncate max-w-[200px]">{selectedProductForSerial.name} ({selectedProductForSerial.productCode})</p>
              </div>
              <button onClick={() => setIsSerialModalOpen(false)} className="p-2.5 hover:bg-white hover:shadow-md rounded-2xl transition-all border border-transparent hover:border-slate-100"><X size={20} className="text-slate-400" /></button>
            </div>
            
            <div className="p-8 border-b border-slate-50 bg-white shrink-0">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 mb-3 block">Unit Identification (Barcode/SN)</label>
              <div className="flex gap-3">
                <div className="relative flex-1 group">
                  <Barcode className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                  <input 
                    type="text" autoFocus value={newSerialInput} onChange={(e) => setNewSerialInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddSerial()}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-[1.25rem] text-[12px] font-bold outline-none focus:border-indigo-500 focus:bg-white shadow-sm transition-all"
                    placeholder="E.g. SN-882-GTX"
                  />
                </div>
                <button onClick={handleAddSerial} disabled={saving || !newSerialInput.trim()} className="bg-indigo-600 text-white px-5 rounded-[1.25rem] shadow-xl shadow-indigo-100 disabled:opacity-50 transition-all flex items-center justify-center hover:bg-indigo-700 active:scale-95"><Send size={20} /></button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-slate-50/20">
              <div className="space-y-3">
                <div className="px-2 mb-2 text-[9px] font-black text-slate-400 uppercase tracking-widest">Active Units ({allSerials.filter(s => s.productId === selectedProductForSerial.id).length})</div>
                {allSerials.filter(s => s.productId === selectedProductForSerial.id).map((s) => (
                  <div key={s.id} className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-2xl hover:border-indigo-200 transition-all group shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors"><Hash size={16} /></div>
                      <div>
                        <p className="text-[11px] font-black text-slate-700 tracking-tight">{s.serialNumber}</p>
                        <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest">{s.status.replace(/_/g, ' ')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-white flex justify-center shrink-0">
               <button onClick={() => setIsSerialModalOpen(false)} className="px-10 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest text-slate-500 hover:text-slate-800 transition-all">Close Session</button>
            </div>
          </div>
        </div>
      )}

      {/* Main Registry Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200 text-left">
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl border border-slate-200 animate-in zoom-in-95 overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-[15px] font-black text-slate-800 uppercase tracking-tight">{editingProduct ? 'Modify Registry Spec' : 'New Master Registration'}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-widest italic">Product Identity Definition</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white hover:shadow-md rounded-xl transition-all"><X size={20} className="text-slate-400" /></button>
            </div>
            
            <form onSubmit={handleSaveProduct} className="p-8 space-y-6 text-left max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Official Name</label>
                  <div className="relative group">
                    <Package className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <input 
                      type="text" required value={formData.name} 
                      onChange={(e) => setFormData({...formData, name: e.target.value})} 
                      className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-sm" 
                      placeholder="E.g. NVIDIA GeForce GTX 1050Ti"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Classification Condition</label>
                  <div className="flex gap-2 p-1.5 bg-slate-50 rounded-2xl border border-slate-200">
                    <button type="button" onClick={() => setFormData({...formData, productType: ProductType.NEW})} className={`flex-1 py-3 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${formData.productType === ProductType.NEW ? 'bg-white text-indigo-600 shadow-md border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>New</button>
                    <button type="button" onClick={() => setFormData({...formData, productType: ProductType.SECOND})} className={`flex-1 py-3 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${formData.productType === ProductType.SECOND ? 'bg-white text-indigo-600 shadow-md border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>Second</button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Unit Selling Price (MMK)</label>
                  <div className="relative group">
                    <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <input type="number" required min="0" value={formData.sellingPrice} onChange={(e) => setFormData({...formData, sellingPrice: Number(e.target.value)})} className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 shadow-sm transition-all" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Parent Category</label>
                  <div className="relative group">
                    <Layers className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <select required value={formData.categoryId || ''} onChange={(e) => setFormData({...formData, categoryId: Number(e.target.value)})} className="w-full pl-12 pr-10 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 appearance-none shadow-sm transition-all">
                      <option value="">Choose Taxonomy Node</option>
                      {flatCategoryOptions.map(opt => <option key={opt.id} value={opt.id}>{opt.displayName}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Manufacturer Brand</label>
                  <div className="relative group">
                    <Tag className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <select required value={formData.brandId || ''} onChange={(e) => setFormData({...formData, brandId: Number(e.target.value)})} className="w-full pl-12 pr-10 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 appearance-none shadow-sm transition-all">
                      <option value="">Select Brand Label</option>
                      {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-2 text-left">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Base Measurement Unit</label>
                  <div className="relative group">
                    <Ruler className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={16} />
                    <select required value={formData.unitId || ''} onChange={(e) => setFormData({...formData, unitId: Number(e.target.value)})} className="w-full pl-12 pr-10 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 appearance-none shadow-sm transition-all">
                      <option value="">Select Unit</option>
                      {units.map(u => <option key={u.id} value={u.id}>{u.unitName}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Internal Taxonomy Remarks</label>
                <textarea rows={3} value={formData.remark} onChange={(e) => setFormData({...formData, remark: e.target.value})} className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold outline-none focus:border-indigo-500 shadow-sm transition-all" placeholder="Any specific technical observations or descriptions..." />
              </div>

              <div className="flex gap-4 pt-4 shrink-0">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 border border-slate-200 rounded-[1.25rem] text-[11px] font-black uppercase tracking-widest bg-white text-slate-500 hover:bg-slate-50 transition-all shadow-sm">Discard</button>
                <button type="submit" disabled={saving} className="flex-[2] py-4 bg-indigo-600 text-white rounded-[1.25rem] text-[11px] font-black uppercase tracking-widest shadow-2xl shadow-indigo-600/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2 hover:bg-indigo-700">
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} Finalize & Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductManagement;
